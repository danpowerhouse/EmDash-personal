# EmDash Platform v5 — revision notes

This revision corrects the AI and intake architecture around the actual EmDash source.

## Product decisions

- ChatGPT remains the conversational AI interface. It connects to EmDash through the existing `/_emdash/api/mcp` endpoint. No second chatbot is installed.
- The native EmDash Forms plugin is installed; the core Comments Inbox is visible. The Media Library, content APIs and MCP remain native.
- A small `platform-intake` plugin adds append-only capture/list/get MCP tools in plugin storage. It does not create operational records or execute actions.
- Deterministic triage runs first. Only ambiguous items can call the optional Anthropic/Claude adapter. The model has no tools and can only return a validated proposal. LLM fallback is disabled by default until key/model configuration and data-processing review are complete.
- n8n remains deferred. Email remains the chosen notification channel, but the provider is not configured.
- The existing audit-log plugin remains installed.

## Source review findings

- EmDash 1.4.0 already has the Comments Inbox, Media Library, MCP, API, revisions, search and plugin infrastructure.
- `@emdash-cms/plugin-forms` 0.2.12 supplies forms and its own submissions inbox.
- The supplied source has narrow AI implementations: Workers AI/Llama Guard for comment moderation and Cloudflare AI Search for search/retrieval. It does not provide a reusable general-purpose LLM client.
- The new triage module is therefore deliberately separate and provider-adapted rather than misusing AI Moderation or AI Search.

## Validation status

- Deterministic-first triage tests and policy checks are included.
- Static syntax, package metadata, seed, TypeScript and Cloudflare build checks still need to be run after `npm install` in the consuming environment.
- Live Cloudflare provisioning/deployment, Anthropic calls, ChatGPT connector authorization and email delivery have not been performed.


## Final review patch (2026-11-01)

Applied the external review findings: require a committed npm lockfile; pin GitHub Actions to immutable SHAs; make production audit non-blocking while retaining the PR gate; provision Cloudflare resources before Astro build and verify generated deploy config; scope R2 lookups to EU and check default-jurisdiction name collisions; verify R2 creation; require Contributor-level intake permissions; return summaries from list and full content only from get; ignore `.wrangler/`; declare `TRIAGE_MODEL` in Wrangler vars; log provider errors without submitted content; remove the optional Anthropic temperature field; and enable Worker observability. Added dependency-free bootstrap regression tests and generated-config verification.

The project ZIP intentionally does not contain `package-lock.json`: the build environment cannot reach the npm registry to generate a genuine resolved lockfile. Run `npm install` on a machine with registry access and commit the resulting lockfile before the GitHub workflows can run. Full `npm ci`, EmDash seed validation, Astro typecheck and production build remain to be run in GitHub Actions.


## Documentation consistency patch (2026-11-01)

Documentation changes plus two low-risk hardening edits (below); no application source, dependency or Wrangler configuration changes.

- README: removed the stale statement that CI creates and commits `package-lock.json`. The workflows require a lockfile you commit yourself and never write back to `main`.
- `docs/INTAKE-AND-TRIAGE.md`: capture uses route permission `content:create`; list/get use `content:read_drafts` (matching `src/plugins/platform-intake/index.ts`), and list returns summaries only.
- `docs/CHATGPT-MCP.md`, `OPERATORS.md`, `SECURITY.md`, `AUTONOMY-MATURITY.md`, `VALIDATION.md`: stated the intake route permissions explicitly and added a first-run gate. It has not been verified against a live EmDash 1.4.0 that a Contributor token without `content:write` can call `platform-intake__capture`. If capture is denied, the scope decision must be made explicitly and recorded.
- `docs/CLOUDFLARE-DEPLOYMENT.md`: lifecycle list now matches `.github/workflows/deploy.yml` step for step; the lockfile is documented as a prerequisite rather than a CI step.
- Workflows: `actions/checkout` now uses `persist-credentials: false` in `validate.yml` and `deploy.yml` (neither workflow pushes to git, so the token does not need to stay in `.git/config`).
- Dependabot: added a 7-day `cooldown` so newly published releases are not proposed immediately.
- `docs/VALIDATION.md`: added a dependency-hygiene procedure for the five direct dependencies that this project's source does not import. They are deliberately not removed until `npm explain` confirms they are not EmDash peers.
- Permission gate: least privilege is the stated default; escalating scopes requires a recorded human decision.
- Packaging: this archive has its files at the root so `.github/workflows` is picked up by GitHub when the contents are copied into the repository root.

Unchanged and still open: no `package-lock.json`; `npm ci`, seed validation, typecheck, production build, live Cloudflare provisioning and the first-run capture gate above have not been run.


## Implementation hardening patch (2026-11-01)

Applied a focused intake/triage hardening pass without changing the authority model or adding dependencies:

- Centralized fallback summary generation; normalized previews are capped at 240 characters and visibly truncated. Empty content produces a safe placeholder in the fallback path.
- Tightened Anthropic response validation: category is allowlisted, confidence is bounded to 0..1, and summary/action/rationale must be non-empty and within length limits. Returned text fields are trimmed.
- Tightened MCP tool output schemas to use the actual triage category enum and confidence bounds rather than arbitrary strings/numbers.
- Capture rejects whitespace-only content, trims optional title/source-reference metadata, and preserves the submitted content body verbatim.
- Added regression tests for malformed model output and bounded fallback previews.

Validation executed successfully: `npm run check:scaffold`, `npm run check:automation`, `npm run check:intelligence`, and `npm run check:bootstrap`. `npm run check:build-config` was also attempted but correctly could not run because no Astro build output exists. A package-lock generation attempt timed out; no lockfile was fabricated. Dependency installation, EmDash seed validation, Astro typecheck/build, live MCP permission verification, Cloudflare provisioning and deployment remain outstanding.
