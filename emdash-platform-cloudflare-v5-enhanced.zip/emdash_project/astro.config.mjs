import cloudflare from "@astrojs/cloudflare";
import react from "@astrojs/react";
import { d1, r2 } from "@emdash-cms/cloudflare";
import { defineConfig } from "astro/config";
import auditLog from "@emdash-cms/plugin-audit-log";
import { formsPlugin } from "@emdash-cms/plugin-forms";
import { platformIntakePlugin } from "./src/plugins/platform-intake/index.ts";
import emdash from "emdash/astro";

const siteUrl = process.env.EMDASH_SITE_URL;

export default defineConfig({
  output: "server",
  adapter: cloudflare(),
  integrations: [
    react(),
    emdash({
      database: d1({ binding: "DB", session: "auto", coalesce: true }),
      storage: r2({ binding: "MEDIA" }),
      plugins: [auditLog, formsPlugin({ defaultSpamProtection: "honeypot" }), platformIntakePlugin()],
      mcp: true,
      ...(siteUrl ? { siteUrl } : {}),
      admin: {
        logo: "/brand/logo.svg",
        siteName: "EmDash Platform",
        footerLabel: "Private workspace",
        hiddenNavItems: ["redirects", "widgets", "sections", "bylines", "import"],
      },
    }),
  ],
  devToolbar: { enabled: false },
});
