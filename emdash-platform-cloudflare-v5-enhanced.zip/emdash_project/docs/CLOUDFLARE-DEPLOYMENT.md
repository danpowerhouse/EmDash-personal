# Cloudflare deployment and GitHub Actions

This project follows EmDash 1.4.0's Cloudflare template, adapter and Worker entrypoint. GitHub Actions owns provisioning and deployment after the one-time secrets are configured.

## EU data location

The workflow creates the D1 database with `jurisdiction: eu` and the R2 bucket with the `cf-r2-jurisdiction: eu` header. `wrangler.jsonc` declares `jurisdiction: "eu"` on the R2 binding. D1 and R2 jurisdictions are immutable after creation; the bootstrap script therefore refuses to deploy if an existing resource with the configured name is not EU-scoped. It never deletes or silently replaces resources.

EU jurisdiction constrains where D1 data runs/persists and where R2 objects are stored. It does **not** by itself force all Worker compute, request handling, logs, GitHub Actions runners, external LLM providers, or n8n processing to remain in the EU. Consider Cloudflare Regional Services and the data flows of connected services separately if strict end-to-end residency is required.

## One-time GitHub configuration

Create a GitHub environment named `production` under **Settings → Environments**, then add these environment secrets to it:

| Secret | Purpose |
|---|---|
| `CLOUDFLARE_API_TOKEN` | Account-scoped token for resource provisioning and Worker deployment |
| `CLOUDFLARE_ACCOUNT_ID` | Cloudflare account identifier |
| `EMDASH_ENCRYPTION_KEY` | EmDash encryption key generated once with `node scripts/generate-encryption-key.mjs` |
| `ANTHROPIC_API_KEY` (optional) | Only for Claude-assisted ambiguous-item triage after explicit enablement and data-processing review |

The API token needs these account permissions: **Workers Scripts: Edit**, **D1: Edit**, and **Workers R2 Storage: Edit**. Scope it to the one Cloudflare account used by this project. Do not use the Global API Key.

Optional environment variable `EMDASH_SITE_URL` sets the canonical URL during the Astro build and in Worker runtime vars. Set it to the `workers.dev` URL after first deployment or to a custom domain. It also enables the post-deployment `/health.json` check. If you only want a separate health-check target, set `EMDASH_HEALTHCHECK_URL`. Leave required reviewers disabled on `production` if you want fully unattended deployments.

## Automated deployment lifecycle

**Prerequisite (done by you, not by CI):** run `npm install` on a network-enabled machine and commit the resulting `package-lock.json`. Both workflows fail at their first step without it, and CI never writes back to your repository.

On a push to `main` or manual `workflow_dispatch`, GitHub Actions performs these steps in order:

1. Check out the repository, require the committed lockfile, set up Node (version from `.nvmrc`) and run `npm ci`. A dependency audit is reported but does not block production deploys.
2. Run `npm run check`: scaffold checks, operating-policy check, triage tests, bootstrap tests, EmDash's seed validator and the Astro typecheck.
3. Call `scripts/cloudflare-bootstrap.mjs` using the Cloudflare API before the Astro build. It filters D1 by name and verifies EU jurisdiction. It lists R2 in both EU and default jurisdictions, refuses same-name collisions, creates in EU if absent, and verifies the bucket is visible after creation.
4. Inject the returned D1 UUID into `wrangler.jsonc` for that CI run and declare the R2 binding jurisdiction. The database ID is an identifier, not a secret. The workflow does not print API tokens or encryption keys.
5. Run the Astro production build, then `npm run check:build-config` to confirm the generated deploy config contains the provisioned D1 ID.
6. Write `EMDASH_ENCRYPTION_KEY` and, only if supplied, `ANTHROPIC_API_KEY` to a temporary, permission-restricted JSON secrets file and deploy with Wrangler `--secrets-file`.
7. If `EMDASH_SITE_URL` or `EMDASH_HEALTHCHECK_URL` is set, poll `/health.json` until it responds successfully.
8. Remove the temporary secrets file even if a prior step fails.

Pull requests run validation and build only; they receive no Cloudflare credentials and cannot provision or deploy resources.

## First deployment

1. Push this repository to a private GitHub repository.
2. Create the `production` GitHub environment and add the three environment secrets above. Generate `EMDASH_ENCRYPTION_KEY` once and store a recovery copy securely. Leave required reviewers disabled for unattended deployment.
3. Push to `main` or select **Actions → Deploy EmDash Platform to Cloudflare → Run workflow**.
4. Open the deploy job log and copy the `workers.dev` URL.
5. Add that URL as the `production` environment variable `EMDASH_SITE_URL` and re-run the workflow. Future deployments will run the health check automatically.
6. Complete EmDash first-run setup at `/_emdash/admin/`, then create the dedicated ChatGPT Contributor identity, enable the `platform-intake` MCP tools after reviewing them, and test the ChatGPT MCP connection.

## Resource names and safety

Default names are `emdash-platform` for the Worker and D1 database, and `emdash-platform-media` for the R2 bucket. Choose final names before first deployment. Renaming later creates a new resource and does not move existing data.

The bootstrap script is deliberately create-or-verify only. It does not delete, empty, rename, or migrate existing resources. If a same-named resource is not EU-jurisdictional, the workflow fails closed. Create a new EU resource and plan a deliberate migration instead; jurisdictions cannot be retrofitted.

## EmDash lifecycle

- `package.json#emdash.seed` embeds `seed/seed.json` into the build.
- EmDash applies pending normal D1 migrations and initial seed schema using its own runtime.
- Do not run SQLite-oriented local seed-apply commands against the remote D1 database.
- Subsequent deploys do not overwrite existing content. Schema evolution must follow EmDash's supported schema-evolution process.

## Backups and recovery

D1 Time Travel is built in. Cloudflare documents point-in-time restore for up to 7 days on Workers Free and 30 days on Workers Paid. Restores are destructive; record the restore point and test the recovery procedure before using it. Keep the EmDash encryption key separately from the database. R2 media and D1 database recovery are separate concerns; test both.

For long-term retention beyond D1 Time Travel, add a separate encrypted export-and-retention process after choosing the retention period and backup access policy. Do not send database exports to GitHub Actions artifacts.

## Operational notes

- The Worker Cron Trigger runs every minute for EmDash scheduled publishing and maintenance.
- R2 is private; do not enable public bucket access.
- The Worker URL is not authentication. Use EmDash's existing authentication and RBAC.
- D1/R2 usage and Worker requests may incur usage-based charges. Check Cloudflare plan limits and billing.
