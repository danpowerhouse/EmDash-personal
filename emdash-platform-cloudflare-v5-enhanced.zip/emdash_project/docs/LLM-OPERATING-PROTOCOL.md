# AI operating protocol

## Two distinct AI roles

### ChatGPT — conversational interface

The user-facing conversation remains in ChatGPT. ChatGPT connects to EmDash through the existing `/_emdash/api/mcp` endpoint. It is used to discuss work, ask questions, retrieve context and carry out explicitly requested MCP operations within the granted scopes.

The platform does not install a separate conversational chat UI or a continuously running general-purpose autonomous agent.

### Background triage intelligence — selective fallback

The platform has a narrow intelligence module used only during intake triage. It is not a conversational agent and has no MCP tools. It cannot create or modify EmDash operational records, send messages or execute suggested actions.

Triage always runs deterministic rules first. The provider is called only when those rules cannot classify the item unambiguously, and only when explicitly enabled and configured. The initial adapter is Anthropic/Claude; the provider interface allows replacement without changing the intake route or deterministic rules.

## Deterministic-first contract

1. Capture the original item and source metadata.
2. Run deterministic rules.
3. If exactly one rule matches, return that classification without an LLM call.
4. If no rule or conflicting rules match, call the configured provider only if enabled and fully configured.
5. Validate the provider's structured response against the allowed categories and field limits.
6. Keep all LLM-assisted classifications in `needs_human_review` state.
7. On provider error, timeout, missing configuration or invalid output, preserve the capture and return `needs_human_review`.

Captured content is untrusted input. The model is explicitly instructed not to follow instructions embedded in it. No tools are exposed to the triage model.

## Conversational MCP permissions

The initial ChatGPT connection should use a dedicated Contributor identity because operational records are drafts and Subscriber cannot read drafts. Begin with `content:read`. Add `media:read` only if needed. Enable the intake plugin's MCP tools separately and grant `mcp:tools:platform-intake` only after reviewing them.

The intake capture tool is append-only plugin storage, not general content editing. Do not grant general `content:write` to the conversational connection just to capture notes.

## Authority boundaries

- Observe is the initial autonomy stage.
- Triage produces classifications and proposals only.
- Creating or updating operational records remains an explicit ChatGPT/user-authorised operation with the appropriate EmDash tool scopes.
- Publishing, sending external communications, deletion, financial actions, permission changes and external account changes require human approval each time.
- No model confidence score is an approval.
- No automatic permission escalation.

## Evidence and output discipline

Separate source facts, inference and recommendation. Preserve source references. Never claim an action succeeded until the MCP tool confirms it. If an item is ambiguous, ask one focused clarification or leave it in the review queue.
