# Tiered LLM autonomy

## Principle

Autonomy is earned through observed reliability and explicit human permission. It is never granted by model confidence, elapsed time, a successful demo, or an automated score. Permission changes are made by the human in EmDash and/or the operator credential configuration.

## Stages

| Stage | Default | Allowed | Not allowed |
|---|---|---|---|
| Observe | **Enabled initially** | Read, search, summarise, prepare briefs and proposals | Any write, publishing or external side effect |
| Draft | Disabled until approved | Create and update draft records in explicitly approved collections | Publish, delete, external communication, permission/schema changes |
| Bounded execute | Disabled until separately approved | A narrow allowlist of reversible, low-risk actions with limits | Anything outside the allowlist; financial, legal, public or irreversible actions |
| High impact | Always human-gated | Prepare a proposal and explain consequences | Autonomous execution |

## Promotion gates

### Observe → Draft
Require all of the following:
1. A human reviews a meaningful sample of the operator's reads and summaries.
2. Source references are accurate and uncertainty is stated.
3. The operator correctly distinguishes facts, inference and recommendations.
4. A dedicated non-admin identity and token are tested.
5. The human explicitly authorises draft-write scopes.

### Draft → Bounded execute
Require all of the following:
1. A defined action allowlist, collection scope and rate limit.
2. Successful tests of allowed and denied operations.
3. Idempotency and duplicate prevention for each action.
4. A recovery/undo path where technically possible.
5. Human approval of the exact action class and credential scopes.

### Bounded execute → High impact
There is no autonomous promotion. High-impact actions remain individually approved.

## Always human-approved

- Publishing externally visible content.
- Sending messages to people outside the system.
- Deleting or permanently deleting records.
- Changing users, roles, tokens, permissions or schema.
- Financial transactions, contracts or legal commitments.
- Changing external accounts, infrastructure or security settings.

## Implementation rules

- Use separate EmDash identities/tokens for read-only and write-capable operators.
- Keep the initial token read-only for operational records (`content:read`, plus `mcp:tools:platform-intake` for the append-only inbox); do not issue `content:write` until the Draft gate passes. Appending to the intake queue is the one write the Observe stage permits, and it must be verified at first run (see `docs/CHATGPT-MCP.md`).
- If draft writes are approved, use a dedicated Contributor/Author identity as appropriate to EmDash ownership rules and test exact record-ownership cases.
- Do not assume workspace/organisation references enforce authorization.
- Never automatically widen token scopes or promote an autonomy stage.
- Record the approved stage, action allowlist, date, human approver and credential identity in operating documentation.
- If approval is missing, expired, ambiguous or unavailable, do not execute.

## Human-facing behaviour

Show the human only the proposed action, affected records, reason, impact, reversibility and approval request. Keep detailed tool traces, permission checks, retries and diagnostics in internal logs. Never present an autonomy stage as a productivity score.
