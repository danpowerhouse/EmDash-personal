# Activity, revisions and human approval

## Existing EmDash facilities

All ten collections in the seed enable `revisions`. Use EmDash's existing revision history, compare and restore UI/API for content change history. Do not build a separate content revision service.

This project registers the first-party `@emdash-cms/plugin-audit-log` through EmDash `plugins: []`. In this Cloudflare configuration, it is a trusted plugin running in the host Worker. It is not registered in `sandboxed: []` and does not require Worker Loader. Review and trust the plugin code and manifest before deployment. Its manifest declares `content:read`, `content:write` and `media:read`; `content:write` is needed to register its before-save hook even though this plugin returns the draft unchanged.

The plugin stores:

- Content create/update events, with collection and record ID, timestamp, before/after data where available, and the actor's EmDash user ID when the hook event provides one.
- Content delete events, with collection and record ID.
- Media upload events, with media record ID.

## Coverage limitations

Do not describe this as a complete immutable AI/operator audit ledger:

- The plugin records EmDash user ID, not the personal access token ID or OAuth client identity.
- The create/update hook includes `event.actor?.id`; delete and media-upload entries in the inspected implementation do not include actor identity.
- The previous-state cache is module-scoped memory and best-effort, so the `before` snapshot may be absent.
- It does not record prompts, model reasoning, MCP requests/responses as a complete trace, human approvals outside EmDash, or external side effects in other systems.
- Audit storage is plugin storage in D1, not a tamper-proof or independently retained compliance archive.

Keep ChatGPT conversation/tool traces and the platform intake record IDs as separate evidence. The narrow background triage adapter records its classification method and result with the intake item; it does not retain hidden chain-of-thought. Correlate records with EmDash collection slugs and IDs where possible. n8n execution history is relevant only if n8n is added later.

## Human approval

A state field such as `inbox → ready → done` is useful as an operational convention, but it is **not** an enforced approval boundary. Core RBAC has no per-field rule that prevents an Author-level operator from changing a state field if it can otherwise edit that record.

For actions that must not proceed without human approval, use one of these patterns:

1. **Human review in EmDash:** have the operator create/update a draft or leave a record in `inbox`; the human reviews it in the EmDash admin and makes the approval change themselves. This is a workflow convention, not an unbypassable technical gate if the operator has write access to the field.
2. **Future external approval workflow:** if n8n or another workflow engine is added later, it may hold a durable authenticated approval wait before invoking a consequential EmDash or external action. It is not part of the current installation.
3. **Explicit approval metadata:** add fields such as `approved_by` and `approved_at` only if they provide useful record context. They do not independently enforce approval.

Do not build a new audit database, event bus, approval engine or operator registry at this stage.
