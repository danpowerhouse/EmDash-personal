# Optional n8n integration — deferred

n8n hosting is deliberately deferred. The initial platform must work without it.

ChatGPT is the conversational interface and connects directly to EmDash's existing MCP endpoint. EmDash remains the system of record. The local `platform-intake` plugin handles append-only capture and deterministic-first triage. The optional Claude/Anthropic call is a narrow fallback inside that triage path; it is not an n8n workflow and does not have tool access.

If n8n is introduced later, use it only where it adds real value: multi-step external integrations, durable waits, retries, scheduled aggregation or email delivery. Do not move EmDash authentication, records, revisions, MCP or the deterministic triage rules into n8n.

Any future n8n connection must use a dedicated least-privilege identity, a narrow allowlist of workflows, explicit human approval for consequential actions and an auditable execution record. Never expose workflow editing, credential management or unrestricted execution to an AI client.
