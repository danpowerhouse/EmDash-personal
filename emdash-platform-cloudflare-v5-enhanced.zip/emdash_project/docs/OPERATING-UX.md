# Calm operating experience

## Human-facing rhythm

- Weekday morning brief: 08:15 Europe/Lisbon, email once a provider is selected and tested.
- Friday review: 16:00 Europe/Lisbon, email once a provider is selected and tested.
- Critical exception alerts only; no routine notification stream.

These schedules describe the intended operating experience. They are not evidence that email delivery is live.

## Universal intake

The user should be able to capture information without deciding its destination. ChatGPT remains the conversational command surface and can append intake items through the EmDash MCP `platform-intake` tools. The native Forms and Comments inboxes remain available in EmDash. A later integration can aggregate those native queues after their interfaces and permissions are verified.

## Human interaction

- **Capture:** ChatGPT can append an item to the intake queue when explicitly asked. Capture preserves the original content and source.
- **Orient:** ChatGPT reads and searches EmDash records through MCP within its granted scopes.
- **Prepare:** ChatGPT can prepare plans, drafts, summaries and proposed updates.
- **Decide:** the human approves consequential actions. Email replies are not approvals.

## Diagnostics stay internal

Overdue tasks, stale inbox items, blocked projects, pending decisions, upcoming commitments and 28-day trends are internal diagnostic signals. The user sees concise exceptions and useful recommendations, not a scorecard or raw monitoring dashboard.

## Calm by default

No composite productivity score, no notification flood, no automatic permission escalation and no autonomous high-impact actions. If an item is ambiguous, preserve it and ask for review rather than inventing certainty.
