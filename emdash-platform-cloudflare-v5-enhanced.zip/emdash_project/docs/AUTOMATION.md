# Automation and integrations

## Decisions

- **Conversational AI:** ChatGPT, connected to EmDash through its existing MCP endpoint.
- **Background triage:** deterministic rules first; optional Claude/Anthropic fallback only for ambiguous intake items.
- **Notifications:** email, provider not yet selected or configured.
- **n8n:** deferred; not required for EmDash, MCP, intake capture or triage.
- **Autonomy:** tiered, with read-only Observe as the starting stage.

## Native EmDash functionality

- Core scheduler and scheduled publishing/maintenance remain enabled.
- The audit-log plugin remains installed.
- The first-party Forms plugin is installed for web forms, file attachments and its native submissions inbox.
- The core Comments Inbox is visible in the admin.
- Core MCP remains the integration boundary for ChatGPT.
- The local `platform-intake` plugin adds append-only capture/list/get MCP tools and deterministic-first triage.

## Selective intelligence

The triage module is not a general agent. It has no tools and cannot write operational content. Deterministic rules run first. The Anthropic adapter is called only when the rules cannot classify an item unambiguously and only when explicitly enabled/configured. Its output is validated and left for human review.

Existing EmDash AI features are not repurposed: AI Moderation is comment safety classification; AI Search is search/retrieval. Neither is installed as the general intake classifier.

## n8n later

n8n may be added later for long-running workflows, multi-step external integrations, durable waits and email delivery if those needs justify it. It is not part of the initial platform installation and must not be required for core EmDash or MCP functionality.

## Security

- Do not expose the owner's Admin token.
- Keep ChatGPT's default access read-only, except for the narrow append-only intake plugin tool scope.
- Enable plugin MCP tools only after reviewing each tool and its route permission.
- Never treat an email reply as approval.
- Require authenticated human approval for publishing, external messages, deletion, financial actions, permission changes and external account changes.
