# EmDash source verification notes

These notes reflect inspection of the supplied EmDash 1.4.0 source archive and the first-party plugin sources relevant to this consuming project. This is a focused implementation review, not a line-by-line audit of all EmDash packages.

## Reused upstream capabilities

| Capability | Source evidence | Platform decision |
|---|---|---|
| CMS/admin/auth/RBAC/revisions/search/REST | EmDash core 1.4.0 | Reuse; do not rebuild |
| MCP | `docs/src/content/docs/reference/mcp-server.mdx`, `packages/core/src/mcp/server.ts` | Use existing `/_emdash/api/mcp`; ChatGPT is the conversational client |
| Comments Inbox | `packages/admin/src/components/comments/CommentInbox.tsx` and admin comments routes | Keep the native inbox visible |
| Forms and Submissions Inbox | `packages/plugins/forms/src/index.ts`, handlers and admin entry | Install pinned `@emdash-cms/plugin-forms` 0.2.12 |
| Media Library | Core media API and storage adapters | Reuse for uploaded media; no duplicate file store |
| Audit log | `packages/plugins/audit-log/emdash-plugin.jsonc` and `src/plugin.ts` | Keep installed and document coverage limits |
| AI Moderation | `packages/plugins/ai-moderation/src/guard.ts` and `src/index.ts` | Existing narrow Workers AI/Llama Guard comment moderation; not a generic triage engine; not installed |
| AI Search | `packages/plugins/ai-search/src/` | Cloudflare AI Search for content indexing/search with optional query rewriting/reranking; not general reasoning; not installed |
| Webhook notifier | `packages/plugins/webhook-notifier/` | Outbound lifecycle notifications; requires broad network capability/sandboxing; not installed |
| Plugin MCP tools | `docs/src/content/docs/plugins/creating-plugins/api-routes.mdx` and `packages/core/src/plugins/types.ts` | Use the plugin MCP extension point for the append-only intake tools |

## Existing AI call patterns

The supplied source does not contain a shared, general-purpose LLM client abstraction.

- AI Moderation calls `env.AI.run("@cf/meta/llama-guard-3-8b", ...)` directly for comment safety classification.
- AI Search delegates indexing and retrieval to Cloudflare AI Search; it is not a general chat/completion service.
- Core MCP exposes tools and does not provide a model.

The platform therefore adds a separate, small provider contract for background triage. It is deterministic-first and uses an optional Anthropic adapter only for ambiguous items. The adapter has no tools and can only return a structured proposal. It is disabled by default.

## Security and permission caveats

- EmDash core RBAC is role/ownership based, not per workspace, organisation, record or field.
- The Forms plugin is a trusted in-process plugin with form/submission storage, attachments, notifications and public submit routes. Review its requested capabilities and configure spam protection/retention before exposing forms.
- Plugin MCP tools must be enabled by an administrator and require both the route permission and plugin MCP scope.
- The `platform-intake` capture tool writes only to its own plugin storage. It is append-only and does not grant general content-write permission.
- The audit plugin is not an immutable operator ledger and does not capture prompts/model decisions or all external side effects.

## Scope

The review checked relevant EmDash source files, package manifests, plugin examples, MCP docs, plugin route/MCP contracts, and the Cloudflare demo configuration. It does not certify production behavior. Validate the pinned packages with `npm install`, `npm run check`, `npm run build`, a local first-run setup and a staging deployment before production.
