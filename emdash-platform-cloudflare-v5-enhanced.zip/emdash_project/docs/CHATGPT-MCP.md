# ChatGPT connection through EmDash MCP

## Product boundary

ChatGPT is the conversational interface: ask questions, discuss projects, give instructions and decide what should happen. EmDash is the system of record and exposes its existing MCP endpoint. This project does not install a second chatbot or agent conversation UI.

The remote MCP endpoint is:

```text
https://YOUR_PUBLIC_HOST/_emdash/api/mcp
```

EmDash supports OAuth discovery and personal access tokens. Prefer OAuth where the ChatGPT connector supports it, so the user can review the requested scopes. Never use the owner's Admin token as a general-purpose connector credential.

## Recommended initial access

Create a dedicated EmDash user with the Contributor role and a narrow token/authorization grant. Contributor is required to read operational drafts; Subscriber is published-only. Start with:

- `content:read` for reading/searching operational collections and drafts.
- `media:read` only if ChatGPT needs to inspect stored media.
- `mcp:tools:platform-intake` only after enabling the intake plugin's MCP tools.

Do not grant `content:write`, `admin`, `schema:write`, `settings:manage`, `transfer:execute` or plugin-management scopes to the conversational connection by default.

The intake capture tool is a deliberately narrow exception: it appends an inbox item to plugin storage and does not grant general EmDash content-write authority. Its route still requires authentication and the plugin-specific MCP tool scope.

Route permissions declared by the plugin: `capture` requires `content:create`; `list` and `get` require `content:read_drafts`. The Contributor role satisfies all three. These are role permissions on the plugin routes, separate from the token scopes above.

**First-run gate (not yet verified against a live EmDash 1.4.0):** confirm that the Contributor connector holding only `content:read` and `mcp:tools:platform-intake` can call `platform-intake__capture`. If EmDash also requires the `content:write` token scope for a `content:create` route, capture will be denied. In that case do not widen the scope silently: make an explicit decision, recorded with date, approver, identity and scopes as described in `docs/AUTONOMY-MATURITY.md`, between (a) granting the narrowest scope that allows capture, accepting that the connector can then also create draft records through core tools, or (b) keeping the connector read-only and capturing through another authenticated path. Least privilege is the default: stay on (b) until a human approves (a), and never apply (a) to the owner's Admin account.

## Connect and verify

1. Complete EmDash first-run setup and set a stable HTTPS site URL.
2. In EmDash admin, open plugin settings for `platform-intake` and enable its MCP tools after reviewing their descriptions, routes and permissions.
3. In ChatGPT, add the remote MCP server using the URL above and complete the supported authentication flow. The exact connector UI is controlled by ChatGPT and may vary by account/plan.
4. Review the requested scopes. Grant only the read scopes and `mcp:tools:platform-intake` needed for the workflow.
5. Ask ChatGPT to list available tools. Verify the platform intake tools appear and that ordinary content write/delete/publish tools are not authorised.
6. Test capture with a harmless note, then retrieve it by ID. Confirm original content and triage metadata are preserved. This step is also the first-run gate described above: if capture is denied, stop and make the scope decision explicitly.

Do not paste PAT values into a conversation, project file, GitHub issue or shell command history. Store credentials in the connector's secure authentication store.

## Roles of the two AI systems

- ChatGPT: interactive conversation, user instructions, reasoning with MCP tools and human approval.
- Background triage intelligence: narrow classification fallback invoked by the platform only when deterministic rules cannot classify an intake item. It cannot use tools or execute actions.

These are separate paths. ChatGPT does not need to be replaced by Claude, and Claude does not become the platform's chat interface.
