# Email notifications

Email is the selected human notification channel. No provider has been selected or configured yet, so the platform must not claim to have sent a morning brief, weekly review or exception alert.

The Forms plugin can send submission notifications when an email provider is configured in EmDash. This is separate from the platform's scheduled notification delivery.

Inbound email capture is not enabled in this revision. It requires a receiving provider/route and an authenticated sender policy. Do not treat forwarded mail or an email reply as an approval.

When a provider is selected, evaluate EU data-processing terms, DPA, data location, webhook signature support, attachment handling, retries and deliverability. Keep notification content concise and avoid including sensitive payloads where a secure EmDash link is safer.
