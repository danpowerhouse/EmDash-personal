// Generated and maintained by EmDash's Astro integration.
// Keep the EmDash locals type reference in this consuming project.
/// <reference types="emdash/locals" />
