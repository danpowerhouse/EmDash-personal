import assert from "node:assert/strict";
import { provisionResources } from "./lib/cloudflare-bootstrap-core.mjs";

function fakeApi() {
  const state = { d1: [], eu: [], default: [], calls: [] };
  const api = async (path, options = {}) => {
    state.calls.push({ path, options });
    if (path.startsWith("/d1/database?") || path === "/d1/database") {
      if (options.method === "POST") { const item = { name: options.body.name, uuid: "d1-eu-id", jurisdiction: "eu" }; state.d1.push(item); return item; }
      return state.d1;
    }
    if (path.startsWith("/r2/buckets?") && options.headers?.["cf-r2-jurisdiction"] === "eu") return { buckets: state.eu };
    if (path.startsWith("/r2/buckets?") && options.headers?.["cf-r2-jurisdiction"] === "default") return { buckets: state.default };
    if (path === "/r2/buckets" && options.method === "POST") { state.eu.push({ name: options.body.name, jurisdiction: "eu" }); return {}; }
    throw new Error(`Unexpected fake API call ${path}`);
  };
  return { api, state };
}
const template = () => ({ d1_databases: [{ binding: "DB", database_name: "emdash-platform" }], r2_buckets: [{ binding: "MEDIA", bucket_name: "emdash-platform-media" }] });
{
  const { api, state } = fakeApi(); const config = template();
  await provisionResources({ config, api, log: () => {} });
  await provisionResources({ config, api, log: () => {} });
  assert.equal(state.d1.length, 1); assert.equal(state.eu.length, 1);
  assert.equal(config.d1_databases[0].database_id, "d1-eu-id");
  assert.ok(state.calls.some((call) => call.options.headers?.["cf-r2-jurisdiction"] === "eu"));
  assert.ok(state.calls.some((call) => call.options.headers?.["cf-r2-jurisdiction"] === "default"));
}
{
  const { api, state } = fakeApi(); state.default.push({ name: "emdash-platform-media", jurisdiction: "default" });
  await assert.rejects(() => provisionResources({ config: template(), api, log: () => {} }), /default jurisdiction/);
}
{
  const { api, state } = fakeApi(); state.d1.push({ name: "emdash-platform", uuid: "wrong", jurisdiction: "us" });
  await assert.rejects(() => provisionResources({ config: template(), api, log: () => {} }), /not 'eu'/);
}
console.log("PASS bootstrap is idempotent, EU-scoped, verifies R2 after create, and refuses jurisdiction collisions.");
