import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { provisionResources } from "./lib/cloudflare-bootstrap-core.mjs";

export async function main() {
  const token = process.env.CLOUDFLARE_API_TOKEN;
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
  if (!token || !accountId) throw new Error("CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID are required.");
  const configPath = new URL("../wrangler.jsonc", import.meta.url);
  const config = JSON.parse(await readFile(configPath, "utf8"));
  const apiBase = `https://api.cloudflare.com/client/v4/accounts/${accountId}`;
  async function api(path, { method = "GET", body, headers = {} } = {}) {
    const response = await fetch(`${apiBase}${path}`, { method, headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", ...headers }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    let payload;
    try { payload = await response.json(); } catch { throw new Error(`Cloudflare API returned non-JSON (${response.status}) for ${method} ${path}`); }
    if (!response.ok || payload.success === false) {
      const details = (payload.errors ?? []).map((item) => item.message).join("; ");
      throw new Error(`Cloudflare API ${method} ${path} failed (${response.status}): ${details || "unknown error"}`);
    }
    return payload.result;
  }
  await provisionResources({ config, api });
  if (process.env.EMDASH_SITE_URL) { config.vars ??= {}; config.vars.EMDASH_SITE_URL = process.env.EMDASH_SITE_URL; }
  await writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`);
  console.log("Cloudflare resources are ready. Wrangler config has the real D1 ID and EU R2 binding.");
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  main().catch((error) => { console.error(error.message); process.exitCode = 1; });
}
