import { readFile } from "node:fs/promises";
import process from "node:process";

const fail = (message) => {
  console.error(`FAIL ${message}`);
  process.exitCode = 1;
};
const pass = (message) => console.log(`PASS ${message}`);

const seed = JSON.parse(await readFile(new URL("../seed/seed.json", import.meta.url), "utf8"));
const pkg = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
const wrangler = JSON.parse(await readFile(new URL("../wrangler.jsonc", import.meta.url), "utf8"));
const expected = ["workspaces", "organisations", "goals", "projects", "tasks", "contacts", "knowledge", "decisions", "resources", "commitments"];
const supportedFieldTypes = new Set(["string", "text", "url", "number", "integer", "boolean", "datetime", "select", "multiSelect", "portableText", "json", "repeater", "blocks", "image", "file", "reference", "slug"]);
const supportedSupports = new Set(["drafts", "revisions", "preview", "scheduling", "search", "seo"]);
const reservedCollectionSlugs = new Set(["content", "media", "users", "revisions", "taxonomies", "options", "audit_logs", "reorder", "relations"]);
const reservedFieldSlugs = new Set(["id", "slug", "status", "author_id", "primary_byline_id", "created_at", "updated_at", "published_at", "scheduled_at", "deleted_at", "version", "live_revision_id", "draft_revision_id", "terms", "bylines", "byline"]);
const slugs = (seed.collections ?? []).map((collection) => collection.slug);

if (seed.version !== "1") fail("seed version must be string '1'");
else pass("seed format version is 1");
if (JSON.stringify(slugs) !== JSON.stringify(expected)) fail(`expected 10 collections in planned order; received ${slugs.join(", ")}`);
else pass("all 10 planned collections are present in the expected order");

const collectionSet = new Set(slugs);
for (const collection of seed.collections ?? []) {
  const prefix = `collection ${collection.slug ?? "(missing slug)"}`;
  if (reservedCollectionSlugs.has(collection.slug)) fail(`${prefix} uses an EmDash-reserved collection slug`);
  if (collection.routable !== false) fail(`${prefix} must be non-routable`);
  for (const feature of collection.supports ?? []) {
    if (!supportedSupports.has(feature)) fail(`${prefix} has unsupported support flag ${feature}`);
  }
  if (!collection.supports?.includes("revisions")) fail(`${prefix} must support revisions`);
  if (!collection.supports?.includes("search")) fail(`${prefix} must support search`);

  const fieldSlugs = new Set();
  for (const field of collection.fields ?? []) {
    const fieldPrefix = `${collection.slug}.${field.slug ?? "(missing slug)"}`;
    if (fieldSlugs.has(field.slug)) fail(`${fieldPrefix} is duplicated`);
    fieldSlugs.add(field.slug);
    if (reservedFieldSlugs.has(field.slug)) fail(`${fieldPrefix} uses an EmDash-reserved field slug`);
    if (!/^[a-z][a-z0-9_]{0,62}$/.test(field.slug ?? "")) fail(`${fieldPrefix} is not a valid EmDash field slug`);
    if (!supportedFieldTypes.has(field.type)) fail(`${fieldPrefix} uses unsupported field type ${field.type}`);
    if (field.type === "reference") {
      const target = field.validation?.targetCollection;
      if (!target || !collectionSet.has(target)) fail(`${fieldPrefix} references missing target collection ${target ?? "(none)"}`);
    }
    if (field.type === "select") {
      const options = field.validation?.options;
      if (!Array.isArray(options) || options.length === 0) fail(`${fieldPrefix} must declare non-empty validation.options`);
      else if (field.defaultValue !== undefined && !options.includes(field.defaultValue)) fail(`${fieldPrefix} defaultValue must be one of its select options`);
    }
  }

  if (collection.titleField && !fieldSlugs.has(collection.titleField)) fail(`${prefix} titleField ${collection.titleField} is not declared`);
  for (const column of collection.admin?.listColumns ?? []) {
    if (!fieldSlugs.has(column)) fail(`${prefix} admin.listColumns references missing field ${column}`);
  }
  if ((collection.admin?.listColumns ?? []).length > 4) fail(`${prefix} admin.listColumns exceeds EmDash's four-column limit`);
}

const contextCollections = ["goals", "projects", "tasks", "contacts", "knowledge", "decisions", "resources", "commitments"];
for (const slug of contextCollections) {
  const collection = seed.collections.find((item) => item.slug === slug);
  const refs = new Set((collection?.fields ?? []).filter((field) => field.type === "reference").map((field) => field.slug));
  for (const requiredRef of ["workspace", "organisation"]) {
    if (!refs.has(requiredRef)) fail(`${slug} is missing its ${requiredRef} reference field`);
  }
}

if (pkg.dependencies?.emdash !== "1.4.0") fail("EmDash must remain pinned to 1.4.0");
else pass("EmDash dependency is pinned to 1.4.0");
if (pkg.dependencies?.["@emdash-cms/cloudflare"] !== "1.4.0") fail("@emdash-cms/cloudflare must be pinned to 1.4.0");
else pass("EmDash Cloudflare adapter is pinned to 1.4.0");
if (pkg.dependencies?.["@astrojs/cloudflare"] !== "14.3.1") fail("@astrojs/cloudflare must be pinned to 14.3.1");
else pass("Astro Cloudflare adapter is pinned to 14.3.1");
if (pkg.dependencies?.["@emdash-cms/plugin-audit-log"] !== "0.2.3") fail("first-party audit plugin must be pinned to 0.2.3");
else pass("first-party audit plugin is pinned to 0.2.3");
if (pkg.dependencies?.["@emdash-cms/plugin-forms"] !== "0.2.12") fail("first-party Forms plugin must be pinned to 0.2.12");
else pass("first-party Forms plugin is pinned to 0.2.12");
if (pkg.dependencies?.zod !== "4.5.4") fail("platform intake plugin must pin zod to 4.5.4");
else pass("platform intake schema dependency is pinned");
if (pkg.dependencies?.pg || pkg.dependencies?.["@aws-sdk/client-s3"]) fail("Cloudflare deployment must not include the Node/Postgres/S3 client dependencies");
else pass("no Node/PostgreSQL/S3-only dependencies are configured");
if (pkg.emdash?.seed !== "seed/seed.json") fail("package.json must point EmDash to seed/seed.json");
else pass("EmDash seed path is configured");
if (wrangler.d1_databases?.find((item) => item.binding === "DB")?.database_name !== "emdash-platform") fail("Wrangler must declare the EmDash D1 binding DB");
else pass("Cloudflare D1 binding DB is configured");
if (wrangler.d1_databases?.find((item) => item.binding === "DB")?.database_id) fail("Do not hardcode a D1 database ID in the template; the EU bootstrap step injects the actual ID after provisioning");
else pass("D1 database ID is injected by the EU bootstrap step after provisioning");
if (wrangler.r2_buckets?.find((item) => item.binding === "MEDIA")?.jurisdiction !== "eu") fail("R2 MEDIA binding must declare EU jurisdiction");
else pass("R2 MEDIA binding is explicitly EU-jurisdictional");
if (!wrangler.triggers?.crons?.includes("* * * * *")) fail("EmDash Cloudflare scheduled handler must retain its minute cron trigger");
else pass("EmDash scheduled handler cron trigger is configured");
if (wrangler.vars?.TRIAGE_LLM_ENABLED !== "false") fail("LLM triage must remain disabled by default");
else pass("LLM triage is disabled by default");
if (wrangler.vars?.TRIAGE_LLM_PROVIDER !== "anthropic") fail("initial triage provider should remain the Anthropic adapter");
else pass("Anthropic is configured as the optional triage provider");
if (!pkg.scripts?.["cf:bootstrap"] || !pkg.scripts?.["cf:secrets"] || !pkg.scripts?.["cf:smoke"] || !pkg.scripts?.["secret:generate"]) fail("Cloudflare bootstrap, key generation, secret upload and smoke-check scripts must be present");
else pass("Cloudflare bootstrap, key generation, secret and smoke-check scripts are wired");

if (process.exitCode) {
  console.error("Scaffold checks failed. This check supplements, but does not replace, `npm run seed:validate` from the installed EmDash package.");
} else {
  console.log("Scaffold checks passed. Run `npm run seed:validate` for EmDash's own seed validator.");
}

const astroConfig = await readFile(new URL("../astro.config.mjs", import.meta.url), "utf8");
if (!astroConfig.includes("formsPlugin({ defaultSpamProtection: \"honeypot\" })")) fail("Forms plugin must be installed with honeypot as the default spam protection");
else pass("Forms plugin is installed with default honeypot protection");
if (!astroConfig.includes("platformIntakePlugin()")) fail("platform-intake plugin must be registered");
else pass("platform-intake plugin is registered");
if (astroConfig.includes('hiddenNavItems: ["comments"')) fail("native Comments Inbox must remain visible");
else pass("native Comments Inbox is not hidden");
if (!astroConfig.includes('mcp: true')) fail("EmDash MCP endpoint must remain enabled");
else pass("EmDash MCP endpoint is enabled");
if (!astroConfig.includes('d1({ binding: "DB", session: "auto", coalesce: true })')) fail("D1 adapter should use EmDash upstream's session auto/coalesce configuration");
else pass("D1 adapter uses upstream session auto/coalesce configuration");

const intakeSource = await readFile(new URL("../src/plugins/platform-intake/index.ts", import.meta.url), "utf8");
if (!intakeSource.includes('permission: "content:create"')) fail("platform-intake capture must require content:create");
else pass("platform-intake capture requires Contributor-level content:create");
if ((intakeSource.match(/permission: "content:read_drafts"/g) ?? []).length < 2) fail("platform-intake list/get must require content:read_drafts");
else pass("platform-intake list/get require Contributor-level draft-read permission");
if (!intakeSource.includes('return { id: item.id, title: item.title, source: item.source, receivedAt: item.receivedAt, triageStatus: item.triageStatus, triage: item.triage }')) fail("platform-intake list must return summaries, not original captured content");
else pass("platform-intake list returns summaries; full content is fetched by get");
if (!wrangler.vars?.TRIAGE_MODEL) fail("TRIAGE_MODEL must be declared in wrangler.jsonc vars so it survives deploys");
else pass("TRIAGE_MODEL is declared in wrangler.jsonc vars");
if (wrangler.observability?.enabled !== true) fail("Cloudflare Worker observability must be enabled");
else pass("Cloudflare Worker observability is enabled");
const gitignore = await readFile(new URL("../.gitignore", import.meta.url), "utf8");
if (!gitignore.split(/\r?\n/).includes(".wrangler/")) fail(".wrangler/ must be ignored");
else pass(".wrangler/ local state is ignored");
const deployWorkflow = await readFile(new URL("../.github/workflows/deploy.yml", import.meta.url), "utf8");
if (deployWorkflow.indexOf("npm run cf:bootstrap") > deployWorkflow.indexOf("npm run build")) fail("Cloudflare bootstrap must run before Astro build");
else pass("deploy workflow provisions resources before build");
if (!deployWorkflow.includes("npm run check:build-config")) fail("deploy workflow must verify generated D1 config after build");
else pass("deploy workflow verifies generated D1 config after build");
