import { readFile } from "node:fs/promises";

const policy = JSON.parse(await readFile(new URL("../automation/operating-policy.json", import.meta.url), "utf8"));
const requiredWorkflows = new Set(["morning-brief", "weekly-review", "inbox-capture", "exception-alert"]);
const actual = new Set((policy.workflows ?? []).map((workflow) => workflow.id));
const errors = [];
if (policy.version !== 1) errors.push("policy version must be 1");
if (policy.timezone !== "Europe/Lisbon") errors.push("timezone must remain Europe/Lisbon unless deliberately changed");
for (const id of requiredWorkflows) if (!actual.has(id)) errors.push(`missing workflow ${id}`);
if (policy.humanExperience?.dailyBrief?.maxPriorities > 3) errors.push("daily brief must show at most three priorities");
if (policy.humanExperience?.weeklyReview?.writeChangesWithoutApproval !== false) errors.push("weekly review must not write without approval");
if (policy.automationAuthority?.defaultMode !== "read_only") errors.push("default operator mode must be read_only");
if (policy.notifications?.primaryChannel !== "email") errors.push("primary notification channel must be email");
if (policy.notifications?.n8nHosting !== "deferred") errors.push("n8n hosting must remain deferred");
if (policy.automationAuthority?.autonomyModel !== "tiered") errors.push("autonomy model must be tiered");
if (policy.automationAuthority?.automaticPermissionEscalation !== false) errors.push("permission escalation must never be automatic");
if (policy.humanExperience?.decisionRequests?.emailReplyIsApproval !== false) errors.push("email replies must not count as approval");
const stages = new Set((policy.automationAuthority?.maturityStages ?? []).map((stage) => stage.id));
for (const id of ["observe", "draft", "bounded_execute", "high_impact"]) if (!stages.has(id)) errors.push(`missing autonomy stage ${id}`);
if (policy.automationAuthority?.externalSideEffects !== "human_approval_required") errors.push("external side effects must require human approval");
if (policy.internalSignals?.neverProduceCompositeProductivityScore !== true) errors.push("composite productivity score must remain disabled");
if (errors.length) { console.error(errors.map((error) => `FAIL ${error}`).join("\n")); process.exit(1); }
console.log("PASS operating policy is valid; quiet-human / read-only-default constraints are intact.");
