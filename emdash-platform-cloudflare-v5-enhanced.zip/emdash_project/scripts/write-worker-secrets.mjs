import { writeFile, chmod } from "node:fs/promises";

const key = process.env.EMDASH_ENCRYPTION_KEY;
const prefix = "emdash_enc_v1_";
const body = key?.startsWith(prefix) ? key.slice(prefix.length) : "";
const decoded = /^[A-Za-z0-9_-]{43}$/.test(body) ? Buffer.from(body, "base64url") : Buffer.alloc(0);
const valid = decoded.length === 32 && decoded.toString("base64url") === body;
if (!valid) {
  console.error("EMDASH_ENCRYPTION_KEY is missing or invalid. Generate it with `node scripts/generate-encryption-key.mjs`.");
  process.exit(2);
}

const secrets = { EMDASH_ENCRYPTION_KEY: key };
if (process.env.ANTHROPIC_API_KEY?.trim()) secrets.ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY.trim();
const path = ".secrets.generated.json";
await writeFile(path, `${JSON.stringify(secrets)}\n`, { mode: 0o600 });
await chmod(path, 0o600);
console.log(`Generated a temporary Worker secrets file (${Object.keys(secrets).length} secret(s); values not displayed).`);
