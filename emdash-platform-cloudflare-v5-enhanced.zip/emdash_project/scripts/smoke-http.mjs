const base = process.env.EMDASH_SITE_URL || process.env.EMDASH_HEALTHCHECK_URL;
if (!base) {
  console.log("Skipping HTTP smoke test: set GitHub Actions variable EMDASH_SITE_URL after the first deployment to enable it.");
  process.exit(0);
}
const url = new URL("/health.json", base).toString();
let lastError;
for (let attempt = 1; attempt <= 10; attempt += 1) {
  try {
    const response = await fetch(url, { headers: { accept: "application/json" }, signal: AbortSignal.timeout(10_000) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const body = await response.json();
    if (body.status !== "ok" || body.service !== "emdash-platform") throw new Error("Unexpected health response body");
    console.log(`Post-deployment health check passed: ${url}`);
    process.exit(0);
  } catch (error) {
    lastError = error;
    if (attempt < 10) await new Promise((resolve) => setTimeout(resolve, 5_000));
  }
}
console.error(`Post-deployment health check failed for ${url}: ${lastError instanceof Error ? lastError.message : String(lastError)}`);
process.exit(1);
