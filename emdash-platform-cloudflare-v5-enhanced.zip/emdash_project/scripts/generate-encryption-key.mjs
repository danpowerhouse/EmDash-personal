import { randomBytes } from "node:crypto";

// Matches EmDash 1.4.0's generateEncryptionKey() format:
// emdash_enc_v1_ + canonical base64url encoding of 32 cryptographically random bytes.
const key = `emdash_enc_v1_${randomBytes(32).toString("base64url")}`;
process.stdout.write(`${key}\n`);
