#!/usr/bin/env bash
set -euo pipefail

if ! command -v git >/dev/null 2>&1; then
  echo "git is required" >&2; exit 1
fi
if [ -f .env ] || [ -f .dev.vars ]; then
  echo "Local secret files exist. They should be ignored; review them before staging." >&2
fi

if [ ! -d .git ]; then
  git init
  git branch -M main
fi

git add .
while IFS= read -r file; do
  case "$file" in
    .env.example|*/.env.example|.dev.vars.example|*/.dev.vars.example) ;;
    .env|*/.env|.env.*|*/.env.*|.dev.vars|*/.dev.vars|.dev.vars.*|*/.dev.vars.*|id_rsa|*/id_rsa|id_ed25519|*/id_ed25519|*.pem|*.key)
      echo "Potential secret file is staged: $file. Unstage/remove it before committing." >&2
      exit 1
      ;;
  esac
done < <(git diff --cached --name-only)

if ! git diff --cached --quiet; then
  git commit -m "Create EmDash Platform consuming project"
fi

echo "Local Git repository is ready. Create a PRIVATE empty GitHub repository, then run:"
echo "  git remote add origin https://github.com/YOUR-USER/emdash-platform.git"
echo "  git push -u origin main"
echo "If origin already exists, inspect it with: git remote -v"
