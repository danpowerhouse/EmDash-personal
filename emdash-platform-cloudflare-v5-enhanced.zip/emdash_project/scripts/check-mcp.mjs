import process from "node:process";

const baseUrl = process.env.EMDASH_MCP_URL;
const token = process.env.EMDASH_MCP_TOKEN;
if (!baseUrl || !token) {
  console.error("Set EMDASH_MCP_URL and EMDASH_MCP_TOKEN. The token is read from the environment and is never printed.");
  process.exit(2);
}

const endpoint = new URL(baseUrl);
if (endpoint.protocol !== "https:" && endpoint.hostname !== "localhost" && endpoint.hostname !== "127.0.0.1") {
  console.error("Refusing to send an MCP bearer token over non-HTTPS transport.");
  process.exit(2);
}

const headers = {
  authorization: `Bearer ${token}`,
  "content-type": "application/json",
  accept: "application/json, text/event-stream",
  "X-EmDash-Request": "1",
};

async function post(payload) {
  const response = await fetch(endpoint, {
    method: "POST",
    headers,
    body: JSON.stringify(payload),
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${body.slice(0, 500)}`);
  let parsed;
  try {
    parsed = JSON.parse(body);
  } catch {
    const dataLine = body.split(/\r?\n/).find((line) => line.startsWith("data: "));
    if (dataLine) parsed = JSON.parse(dataLine.slice(6));
  }
  if (!parsed) throw new Error(`Could not parse MCP response: ${body.slice(0, 500)}`);
  return parsed;
}

try {
  const init = await post({
    jsonrpc: "2.0",
    id: 1,
    method: "initialize",
    params: {
      protocolVersion: "2025-03-26",
      capabilities: {},
      clientInfo: { name: "emdash-platform-smoke-check", version: "0.1.0" },
    },
  });
  if (init.error) throw new Error(init.error.message ?? JSON.stringify(init.error));
  console.log(`Connected to MCP server (${init.result?.serverInfo?.name ?? "server name not supplied"}).`);

  // EmDash creates a fresh stateless transport for each HTTP request. Its own
  // integration test sends initialized + tools/list together in one batch.
  const listed = await post([
    { jsonrpc: "2.0", method: "notifications/initialized" },
    { jsonrpc: "2.0", id: 2, method: "tools/list", params: {} },
  ]);
  const result = Array.isArray(listed) ? listed.find((item) => item.id === 2) : listed;
  if (result?.error) throw new Error(result.error.message ?? JSON.stringify(result.error));
  const tools = result?.result?.tools ?? [];
  if (!Array.isArray(tools)) throw new Error("MCP tools/list response did not contain a tools array.");
  console.log(`Authenticated MCP tool discovery succeeded: ${tools.length} tools visible.`);
  console.log(tools.map((tool) => `- ${tool.name}`).join("\n"));
  console.log("This script performs read-only discovery only. It does not create, update, publish or delete records.");
} catch (error) {
  console.error(`MCP check failed: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}
