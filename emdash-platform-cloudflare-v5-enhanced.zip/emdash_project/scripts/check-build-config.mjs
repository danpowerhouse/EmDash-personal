import { readFile, access } from "node:fs/promises";
import { constants } from "node:fs";
const candidates = [new URL("../dist/server/wrangler.json", import.meta.url), new URL("../dist/server/wrangler.jsonc", import.meta.url)];
let configPath;
for (const candidate of candidates) { try { await access(candidate, constants.R_OK); configPath = candidate; break; } catch {} }
if (!configPath) throw new Error("Astro Cloudflare adapter did not emit dist/server/wrangler.json (or .jsonc).");
const config = JSON.parse(await readFile(configPath, "utf8"));
const d1 = config.d1_databases?.find((item) => item.binding === "DB");
if (!d1?.database_id || d1.database_id === "BOOTSTRAP_REQUIRED") throw new Error("Generated deploy config is missing the provisioned D1 database_id.");
if (config.vars?.EMDASH_SITE_URL !== process.env.EMDASH_SITE_URL && process.env.EMDASH_SITE_URL) throw new Error("Generated deploy config does not contain the expected EMDASH_SITE_URL.");
console.log(`PASS generated deploy config contains D1 database_id (${d1.database_id})${config.vars?.EMDASH_SITE_URL ? " and EMDASH_SITE_URL" : ""}.`);
