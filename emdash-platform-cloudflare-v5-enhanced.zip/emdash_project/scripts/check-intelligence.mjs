import assert from "node:assert/strict";
import { deterministicTriage } from "../src/lib/intelligence/deterministic.ts";
import { triageIntake } from "../src/lib/intelligence/triage.ts";

const explicitTask = deterministicTriage({ source: "chatgpt", content: "Task: follow up with the accountant next Tuesday" });
assert.equal(explicitTask?.category, "task");
assert.equal(explicitTask?.method, "deterministic");

const explicitDecision = deterministicTriage({ source: "manual", content: "Decision: choose between option A and option B" });
assert.equal(explicitDecision?.category, "decision");
assert.equal(deterministicTriage({ source: "manual", content: "Task: call Sam.\nIdea: launch a newsletter." }), null, "conflicting deterministic signals must be escalated");

let modelCalls = 0;
const mockedFetch = async (_url, init) => {
  modelCalls += 1;
  assert.equal(init.method, "POST");
  return new Response(JSON.stringify({
    content: [{ type: "text", text: JSON.stringify({
      category: "knowledge",
      confidence: 0.82,
      summary: "A useful background note.",
      suggestedAction: "Keep as reference material.",
      rationale: "It contains context but no explicit action.",
    }) }],
  }), { status: 200, headers: { "content-type": "application/json" } });
};

const deterministicWithModelEnabled = await triageIntake(
  { source: "manual", content: "Task: send the signed document" },
  { TRIAGE_LLM_ENABLED: "true", TRIAGE_LLM_PROVIDER: "anthropic", TRIAGE_MODEL: "test-model", ANTHROPIC_API_KEY: "test-key" },
  mockedFetch,
);
assert.equal(deterministicWithModelEnabled.method, "deterministic");
assert.equal(modelCalls, 0, "deterministic classifications must not call the model");

const ambiguousWithoutModel = await triageIntake(
  { source: "manual", content: "A few thoughts from today's meeting." },
  { TRIAGE_LLM_ENABLED: "false" },
  mockedFetch,
);
assert.equal(ambiguousWithoutModel.method, "manual_fallback");
assert.equal(modelCalls, 0, "disabled intelligence must not call the model");

const ambiguousWithModel = await triageIntake(
  { source: "manual", content: "A few thoughts from today's meeting." },
  { TRIAGE_LLM_ENABLED: "true", TRIAGE_LLM_PROVIDER: "anthropic", TRIAGE_MODEL: "test-model", ANTHROPIC_API_KEY: "test-key" },
  mockedFetch,
);
assert.equal(ambiguousWithModel.method, "llm");
assert.equal(ambiguousWithModel.status, "needs_human_review");
assert.equal(ambiguousWithModel.category, "knowledge");
assert.equal(modelCalls, 1, "the model should only run for ambiguous items");

const providerFailure = await triageIntake(
  { source: "manual", content: "Unstructured notes with no explicit marker." },
  { TRIAGE_LLM_ENABLED: "true", TRIAGE_LLM_PROVIDER: "anthropic", TRIAGE_MODEL: "test-model", ANTHROPIC_API_KEY: "test-key" },
  async () => new Response("provider unavailable", { status: 503 }),
);
assert.equal(providerFailure.method, "manual_fallback", "provider failures must preserve a review fallback");
assert.equal(providerFailure.status, "needs_human_review");

console.log("PASS deterministic-first triage; model fallback is selective, validated and non-executing");

const invalidModelOutput = await triageIntake(
  { source: "manual", content: "An ambiguous note that needs careful review." },
  { TRIAGE_LLM_ENABLED: "true", TRIAGE_LLM_PROVIDER: "anthropic", TRIAGE_MODEL: "test-model", ANTHROPIC_API_KEY: "test-key" },
  async () => new Response(JSON.stringify({
    content: [{ type: "text", text: JSON.stringify({
      category: "knowledge",
      confidence: 0.7,
      summary: "   ",
      suggestedAction: "Keep this note.",
      rationale: "It is background information.",
    }) }],
  }), { status: 200, headers: { "content-type": "application/json" } }),
);
assert.equal(invalidModelOutput.method, "manual_fallback", "empty model fields must fail closed to human review");
assert.equal(invalidModelOutput.status, "needs_human_review");

const longAmbiguousText = "context ".repeat(60);
const longFallback = await triageIntake(
  { source: "manual", content: longAmbiguousText },
  { TRIAGE_LLM_ENABLED: "false" },
);
assert.equal(longFallback.summary.length, 240, "fallback summaries must respect the 240-character preview limit");
assert.ok(longFallback.summary.endsWith("..."), "truncated fallback summaries must be visibly marked");

console.log("PASS malformed model output fails closed; fallback summaries are bounded and explicit");
