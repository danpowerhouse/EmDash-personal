import { definePlugin } from "emdash";
import type { PluginDescriptor } from "emdash";
import { z } from "zod";
import { triageIntake } from "../../lib/intelligence/triage.ts";
import type { IntakeSource, TriageResult } from "../../lib/intelligence/types.ts";

const PLUGIN_ID = "platform-intake";
const PLUGIN_VERSION = "0.1.0";

const triageOutput = z.object({
  status: z.enum(["classified", "needs_human_review"]),
  method: z.enum(["deterministic", "llm", "manual_fallback"]),
  category: z.enum(["task", "decision", "idea", "knowledge", "contact", "reference", "other"]).nullable(),
  confidence: z.number().min(0).max(1),
  summary: z.string().max(500),
  suggestedAction: z.string().max(500),
  rationale: z.string().max(500),
});
const captureInput = z.object({
  title: z.string().trim().max(240).optional(),
  // Preserve the original text, but reject whitespace-only submissions.
  content: z.string().min(1).max(20_000).refine((value) => value.trim().length > 0, "Content must not be blank"),
  source: z.enum(["chatgpt", "web", "email", "form", "file", "voice", "manual", "api"]),
  sourceRef: z.string().trim().min(1).max(2_000).optional(),
});
const captureOutput = z.object({
  id: z.string(),
  receivedAt: z.string(),
  triage: triageOutput,
});
const listInput = z.object({ limit: z.number().int().min(1).max(50).default(20) });
const listOutput = z.object({ items: z.array(z.object({
  id: z.string(), title: z.string(), source: z.enum(["chatgpt", "web", "email", "form", "file", "voice", "manual", "api"]), receivedAt: z.string(),
  triageStatus: z.enum(["classified", "needs_human_review"]),
  triage: triageOutput,
})) });
const getInput = z.object({ id: z.string().min(1) });
const getOutput = z.object({ item: z.unknown().nullable() });

interface InboxItem {
  id: string;
  title: string;
  content: string;
  source: IntakeSource;
  sourceRef?: string;
  receivedAt: string;
  triage: TriageResult;
  triageStatus: TriageResult["status"];
}

export function platformIntakePlugin(): PluginDescriptor {
  return {
    id: PLUGIN_ID,
    version: PLUGIN_VERSION,
    format: "native",
    entrypoint: new URL("./index.ts", import.meta.url).href,
  };
}

export function createPlugin() {
  return definePlugin({
    id: PLUGIN_ID,
    version: PLUGIN_VERSION,
    capabilities: ["network:request"],
    allowedHosts: ["api.anthropic.com"],
    storage: {
      items: { indexes: ["receivedAt", "source", "triageStatus"] },
    },
    routes: {
      capture: {
        permission: "content:create",
        input: captureInput,
        handler: async (ctx) => {
          const input = captureInput.parse(ctx.input);
          const id = crypto.randomUUID();
          const receivedAt = new Date().toISOString();
          const item: InboxItem = {
            id,
            title: input.title?.trim() || input.content.trim().split(/\s+/).slice(0, 8).join(" "),
            content: input.content,
            source: input.source,
            ...(input.sourceRef ? { sourceRef: input.sourceRef } : {}),
            receivedAt,
            triage: {
              status: "needs_human_review",
              method: "manual_fallback",
              category: null,
              confidence: 0,
              summary: input.content.trim().replace(/\s+/g, " ").slice(0, 240),
              suggestedAction: "Review and classify this inbox item.",
              rationale: "Captured successfully; triage is pending.",
            },
            triageStatus: "needs_human_review",
          };
          // Persist first: capture must survive a slow or unavailable model provider.
          await ctx.storage.items!.put(id, item);

          const { env } = await import("cloudflare:workers");
          const triage = await triageIntake(
            input,
            env as unknown as Parameters<typeof triageIntake>[1],
            ctx.http!.fetch.bind(ctx.http),
          );
          await ctx.storage.items!.put(id, { ...item, triage, triageStatus: triage.status });
          return { id, receivedAt, triage };
        },
      },
      list: {
        permission: "content:read_drafts",
        input: listInput,
        handler: async (ctx) => {
          const { limit } = listInput.parse(ctx.input);
          const result = await ctx.storage.items!.query({ orderBy: { receivedAt: "desc" }, limit });
          return { items: result.items.map((entry) => {
            const item = entry.data as InboxItem;
            return { id: item.id, title: item.title, source: item.source, receivedAt: item.receivedAt, triageStatus: item.triageStatus, triage: item.triage };
          }) };
        },
      },
      get: {
        permission: "content:read_drafts",
        input: getInput,
        handler: async (ctx) => {
          const { id } = getInput.parse(ctx.input);
          return { item: await ctx.storage.items!.get(id) };
        },
      },
    },
    mcp: {
      tools: {
        capture: {
          description: "Capture an incoming item in the EmDash Platform intake queue. Appends only; it does not create tasks, update projects, send messages, or execute the suggested action.",
          route: "capture",
          input: captureInput,
          output: captureOutput,
          destructive: false,
        },
        list: {
          description: "List recent items in the EmDash Platform intake queue, including concise summaries and triage suggestions; original captured content is available only through get.",
          route: "list",
          input: listInput,
          output: listOutput,
          destructive: false,
        },
        get: {
          description: "Retrieve one intake item and its original captured content.",
          route: "get",
          input: getInput,
          output: getOutput,
          destructive: false,
        },
      },
    },
  });
}
