/**
 * EmDash Cloudflare Worker entrypoint.
 * The EmDash Cloudflare runtime supplies Astro's fetch handler and the
 * scheduled maintenance/publishing handler. No Worker Loader is configured:
 * this project does not enable sandboxed marketplace plugins.
 */
import handler, { createScheduledHandler } from "@emdash-cms/cloudflare/worker";

export default {
  ...handler,
  scheduled: createScheduledHandler(),
} satisfies ExportedHandler;
