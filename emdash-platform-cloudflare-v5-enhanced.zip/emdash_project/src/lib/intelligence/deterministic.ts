import type { TriageInput, TriageResult } from "./types.ts";

const RULES: Array<{
  category: NonNullable<TriageResult["category"]>;
  pattern: RegExp;
  action: string;
  rationale: string;
}> = [
  {
    category: "task",
    pattern: /^(?:todo|task|remind me|follow up|please schedule|action item)\b|\b(?:remind me to|follow up with|deadline for|due on)\b/im,
    action: "Review whether this should become a task or commitment.",
    rationale: "The message contains an explicit task or follow-up instruction.",
  },
  {
    category: "decision",
    pattern: /^(?:decision|decision needed|choose|approval required)\b|\b(?:need to decide|which option|approve or reject)\b/im,
    action: "Review the decision context and record the eventual outcome.",
    rationale: "The message explicitly identifies a decision or approval question.",
  },
  {
    category: "idea",
    pattern: /^(?:idea|thought|concept)\s*:/im,
    action: "Keep as an idea for later consideration.",
    rationale: "The message is explicitly labelled as an idea or thought.",
  },
  {
    category: "reference",
    pattern: /^(?:reference|save for reference|article|research|reading)\s*:/im,
    action: "Keep as reference material and link it to relevant knowledge later.",
    rationale: "The message is explicitly labelled as reference or research material.",
  },
];

/**
 * Fast, predictable triage. It deliberately handles only explicit signals;
 * uncertain content is escalated rather than guessed.
 */
export function deterministicTriage(input: TriageInput): TriageResult | null {
  const content = input.content.trim();
  if (!content) return null;

  const title = input.title?.trim() ?? "";
  const searchable = `${title}\n${content}`.trim();
  const matches = RULES.filter((rule) => rule.pattern.test(searchable));

  // Conflicting deterministic signals are ambiguous, not a reason to guess.
  if (matches.length !== 1) return null;

  const match = matches[0]!;
  const summarySource = content.replace(/\s+/g, " ");
  const summary = summarySource.length > 240 ? `${summarySource.slice(0, 237)}...` : summarySource;

  return {
    status: "classified",
    method: "deterministic",
    category: match.category,
    confidence: 0.96,
    summary,
    suggestedAction: match.action,
    rationale: match.rationale,
  };
}
