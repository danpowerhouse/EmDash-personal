export type IntakeSource = "chatgpt" | "web" | "email" | "form" | "file" | "voice" | "manual" | "api";

export type TriageCategory = "task" | "decision" | "idea" | "knowledge" | "contact" | "reference" | "other";

export interface TriageInput {
  title?: string;
  content: string;
  source: IntakeSource;
}

export interface TriageResult {
  status: "classified" | "needs_human_review";
  method: "deterministic" | "llm" | "manual_fallback";
  category: TriageCategory | null;
  confidence: number;
  summary: string;
  suggestedAction: string;
  rationale: string;
}

export interface TriageEnvironment {
  TRIAGE_LLM_ENABLED?: string;
  TRIAGE_LLM_PROVIDER?: string;
  TRIAGE_MODEL?: string;
  ANTHROPIC_API_KEY?: string;
}

export interface IntelligenceProvider {
  classify(input: TriageInput): Promise<Omit<TriageResult, "status" | "method">>;
}
