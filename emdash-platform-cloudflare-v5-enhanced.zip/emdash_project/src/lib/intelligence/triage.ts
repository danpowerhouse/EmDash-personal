import { createAnthropicProvider } from "./anthropic.ts";
import { deterministicTriage } from "./deterministic.ts";
import type { TriageEnvironment, TriageInput, TriageResult } from "./types.ts";

function summarize(content: string, maxLength = 240): string {
  const normalized = content.trim().replace(/\s+/g, " ");
  if (!normalized) return "No content";
  if (normalized.length <= maxLength) return normalized;
  return `${normalized.slice(0, maxLength - 3)}...`;
}

function manualFallback(input: TriageInput, rationale: string): TriageResult {
  return {
    status: "needs_human_review",
    method: "manual_fallback",
    category: null,
    confidence: 0,
    summary: summarize(input.content),
    suggestedAction: "Review and classify this inbox item.",
    rationale,
  };
}

/**
 * Deterministic-first triage with a narrowly scoped LLM fallback.
 * The model can classify and propose; it cannot write to EmDash or execute actions.
 */
export async function triageIntake(
  input: TriageInput,
  env: TriageEnvironment,
  fetchImpl?: typeof fetch,
): Promise<TriageResult> {
  const deterministic = deterministicTriage(input);
  if (deterministic) return deterministic;

  const enabled = env.TRIAGE_LLM_ENABLED === "true";
  const provider = env.TRIAGE_LLM_PROVIDER ?? "anthropic";
  const model = env.TRIAGE_MODEL;
  const apiKey = env.ANTHROPIC_API_KEY;

  if (!enabled || provider !== "anthropic" || !model || !apiKey) {
    return manualFallback(
      input,
      "Deterministic rules could not classify this item, and the LLM fallback is not fully configured.",
    );
  }

  try {
    const intelligence = createAnthropicProvider({ apiKey, model, fetchImpl });
    const classification = await intelligence.classify(input);
    return { status: "needs_human_review", method: "llm", ...classification };
  } catch (error) {
    // Log provider failure metadata without logging submitted content or credentials.
    console.error("[platform-intake] LLM triage failed:", error instanceof Error ? error.message : "unknown provider error");
    // Capture must remain available when the optional model provider is down.
    return manualFallback(
      input,
      "The optional intelligence provider was unavailable or returned an invalid response.",
    );
  }
}
