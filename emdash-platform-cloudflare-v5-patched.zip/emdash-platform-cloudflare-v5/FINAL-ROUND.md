# EmDash Platform v5 — revision notes

This revision corrects the AI and intake architecture around the actual EmDash source.

## Product decisions

- ChatGPT remains the conversational AI interface. It connects to EmDash through the existing `/_emdash/api/mcp` endpoint. No second chatbot is installed.
- The native EmDash Forms plugin is installed; the core Comments Inbox is visible. The Media Library, content APIs and MCP remain native.
- A small `platform-intake` plugin adds append-only capture/list/get MCP tools in plugin storage. It does not create operational records or execute actions.
- Deterministic triage runs first. Only ambiguous items can call the optional Anthropic/Claude adapter. The model has no tools and can only return a validated proposal. LLM fallback is disabled by default until key/model configuration and data-processing review are complete.
- n8n remains deferred. Email remains the chosen notification channel, but the provider is not configured.
- The existing audit-log plugin remains installed.

## Source review findings

- EmDash 1.4.0 already has the Comments Inbox, Media Library, MCP, API, revisions, search and plugin infrastructure.
- `@emdash-cms/plugin-forms` 0.2.12 supplies forms and its own submissions inbox.
- The supplied source has narrow AI implementations: Workers AI/Llama Guard for comment moderation and Cloudflare AI Search for search/retrieval. It does not provide a reusable general-purpose LLM client.
- The new triage module is therefore deliberately separate and provider-adapted rather than misusing AI Moderation or AI Search.

## Validation status

- Deterministic-first triage tests and policy checks are included.
- Static syntax, package metadata, seed, TypeScript and Cloudflare build checks still need to be run after `npm install` in the consuming environment.
- Live Cloudflare provisioning/deployment, Anthropic calls, ChatGPT connector authorization and email delivery have not been performed.


## Final review patch (2026-11-01)

Applied the external review findings: require a committed npm lockfile; pin GitHub Actions to immutable SHAs; make production audit non-blocking while retaining the PR gate; provision Cloudflare resources before Astro build and verify generated deploy config; scope R2 lookups to EU and check default-jurisdiction name collisions; verify R2 creation; require Contributor-level intake permissions; return summaries from list and full content only from get; ignore `.wrangler/`; declare `TRIAGE_MODEL` in Wrangler vars; log provider errors without submitted content; remove the optional Anthropic temperature field; and enable Worker observability. Added dependency-free bootstrap regression tests and generated-config verification.

The project ZIP intentionally does not contain `package-lock.json`: the build environment cannot reach the npm registry to generate a genuine resolved lockfile. Run `npm install` on a machine with registry access and commit the resulting lockfile before the GitHub workflows can run. Full `npm ci`, EmDash seed validation, Astro typecheck and production build remain to be run in GitHub Actions.
