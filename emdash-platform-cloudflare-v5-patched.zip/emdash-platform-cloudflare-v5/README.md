# EmDash Platform — Cloudflare edition

A configuration-first EmDash installation for one individual operating across personal, professional and organisational contexts. EmDash remains the CMS, admin application, identity/RBAC system, content database, REST API and MCP server. This repository is the consuming project: configuration, seed model, branding and integration guidance.

This edition deploys to **Cloudflare Workers**, using **D1** for EmDash's database and **R2** for media. GitHub Actions validates every pull request and deploys `main` to Cloudflare. The production workflow idempotently provisions/verifies EU-jurisdiction D1 and R2 resources, injects the runtime encryption key, deploys, and can run an HTTP smoke test.

## One-time GitHub setup

Create a GitHub environment named `production` under **Settings → Environments**. Add these **three required environment secrets** to it. The optional Anthropic key is only needed if you later enable Claude-assisted fallback triage. The deploy workflow already targets this environment:

- `CLOUDFLARE_API_TOKEN` — account-scoped token with Workers Scripts Edit, D1 Edit, and Workers R2 Storage Edit.
- `CLOUDFLARE_ACCOUNT_ID` — the Cloudflare account ID.
- `EMDASH_ENCRYPTION_KEY` — generate once with `npx emdash secrets generate`; retain a recovery copy in your password manager. The workflow uploads it to the Worker on every deployment without printing it.
- Optional `ANTHROPIC_API_KEY` — only if enabling the selective Claude triage fallback. Do not add it until you have reviewed the data-processing implications and configured `TRIAGE_MODEL` plus `TRIAGE_LLM_ENABLED=true`.

Optional environment variable `EMDASH_SITE_URL` sets the canonical public URL at build and runtime. After the first deploy, set it to the `workers.dev` URL or your custom domain to enable automatic post-deploy health checks. Alternatively set `EMDASH_HEALTHCHECK_URL` solely for the smoke test. For fully unattended deploys, do not configure required reviewers on the `production` environment.

On the first push to `main`, GitHub Actions creates `package-lock.json` if it is missing, commits it back to `main`, then continues the deployment. Later runs use `npm ci`. Pull requests never receive Cloudflare secrets.

## Ground rules

- Keep `emdash` and `@emdash-cms/cloudflare` pinned at `1.4.0` until an explicit upgrade is tested.
- Do not modify EmDash core, admin or auth packages. Do not fork upstream.
- Configure existing EmDash features before writing custom code.
- `workspace` and `organisation` references are organisational grouping, **not tenant isolation or access-control boundaries**. EmDash core RBAC is role-based and does not enforce record/field-level tenancy.
- Do not enable paid add-ons, public R2 access or broad operator write permissions without an explicit human decision. The Worker itself is reachable at its Cloudflare URL; EmDash authentication protects the admin and APIs.
- The initial Cloudflare setup uses EmDash's native authentication. Cloudflare Access is optional and is deliberately not required for the first deployment.

## What's in the model

The seed declares ten non-routable collections:

| Layer | Collections |
|---|---|
| Structure | `workspaces`, `organisations` |
| Planning | `goals` |
| Operations | `projects`, `tasks`, `contacts`, `knowledge`, `decisions`, `resources`, `commitments` |

Operational collections use EmDash reference fields to associate records with workspaces and organisations. Those references are metadata/grouping only, not a security boundary. All collections enable revisions and search. No sample records are seeded.

## Architecture

- **Astro + EmDash 1.4.0** — application and admin.
- **Cloudflare Workers** — application runtime.
- **Cloudflare D1** — EmDash database, bound as `DB`.
- **Cloudflare R2** — private media storage, bound as `MEDIA`.
- **Cloudflare Cron Trigger** — invokes EmDash's existing scheduled maintenance/publishing handler every minute.
- **GitHub Actions** — validates PRs and deploys `main` after checks pass.
- **ChatGPT** — the conversational interface, connected through EmDash's existing `/_emdash/api/mcp` endpoint.
- **Platform intake plugin** — append-only capture/list/get MCP tools plus deterministic-first triage.
- **Forms plugin** — native forms and submissions inbox.
- **Optional Claude/Anthropic adapter** — background triage fallback only; disabled by default.
- **n8n** — deferred; not required for EmDash, MCP, intake capture or triage.

No PostgreSQL, S3 credentials, Worker Loader, Durable Object or separate database service is required for this initial configuration. Sandboxed marketplace plugins are intentionally not enabled; they require additional Worker Loader configuration and Cloudflare plan eligibility.

## Prerequisites

- Cloudflare account with Workers, D1 and R2 available.
- Private GitHub repository containing this project.
- Node.js 22.16+ (Node 24 is selected by `.nvmrc`) for local development.
- A domain managed by the same Cloudflare account is optional. Start with the generated `workers.dev` URL if you do not have one ready.

## 1. Local install and checks

```bash
npm install
cp .dev.vars.example .dev.vars
npx emdash secrets generate
```

For local development, paste the generated key into the ignored `.dev.vars` file if you need encrypted plugin settings locally. For production, add the same key as GitHub Actions secret `EMDASH_ENCRYPTION_KEY`. Never commit it or paste it into chat. Keep a recovery copy in a password manager.

Then run:

```bash
npm run check
npm run build
npm run dev
```

Astro's Cloudflare adapter runs the Worker runtime locally. Open `http://localhost:4321/_emdash/admin/` and complete the first-run setup against local D1/R2 emulation. The first-run wizard applies the schema/structure from the embedded seed. The seed is declared by `package.json#emdash.seed`; use `npm run seed:validate` to validate it. Do not use the CLI seed apply command as a substitute for the Cloudflare first-run setup.

Before pushing, run `npm install` locally and commit the generated `package-lock.json`. Both GitHub workflows require a committed lockfile before setting up the npm cache, then use deterministic `npm ci`. This prevents CI from mutating `main` or writing repository credentials during dependency installation.

## 2. Configure GitHub Actions secrets

In GitHub, open **Settings → Environments → production** and add these environment secrets:

| Secret name | Value |
|---|---|
| `CLOUDFLARE_API_TOKEN` | Account-scoped token with Workers Scripts Edit, D1 Edit and Workers R2 Storage Edit. Scope it to the target Cloudflare account. |
| `CLOUDFLARE_ACCOUNT_ID` | Cloudflare account ID. |
| `EMDASH_ENCRYPTION_KEY` | The value generated with `npx emdash secrets generate`. Store a recovery copy securely. |

Optional environment variable `EMDASH_SITE_URL` can be set after the first deploy to the `workers.dev` URL or your custom domain. It configures the canonical URL and enables the post-deployment health check. `TRIAGE_MODEL` is declared in `wrangler.jsonc` so it persists across deployments; change it there when selecting a supported Anthropic model. Alternatively use `EMDASH_HEALTHCHECK_URL` for a separate health-check URL.

## 3. First deployment

1. Create the `production` GitHub environment and add the three environment secrets above. Leave required reviewers disabled if you want completely unattended deployments.
2. Run `npm install` locally and commit `package-lock.json` (the workflows intentionally fail early if it is absent).
3. Push the project to your private GitHub repository's `main` branch.
4. Open **Actions → Deploy EmDash Platform to Cloudflare** and watch the first run.
5. The workflow provisions/verifies EU D1 and R2 before Astro builds, verifies the generated Worker config contains the D1 ID, uploads runtime secrets, then deploys.
6. Open the Worker URL shown in the Cloudflare dashboard, normally `https://emdash-platform.<your-subdomain>.workers.dev`.
7. Add that URL as the `production` environment variable `EMDASH_SITE_URL` and re-run the workflow to enable automatic health checks.

The deployed Worker applies pending ordinary EmDash migrations on its first request. Before setup is complete, EmDash also applies the schema/structure from the embedded seed once. The setup wizard is served at `/_emdash/admin/`.

The bootstrap script is create-or-verify only. If an existing D1 database or R2 bucket with the configured name is not EU-jurisdictional, deployment stops rather than silently using or replacing it. D1 and R2 jurisdictions cannot be changed after creation.

## 4. Encryption key lifecycle

Generate the key once with `npx emdash secrets generate`. Store it as the GitHub Actions secret `EMDASH_ENCRYPTION_KEY` and retain a recovery copy in a password manager or secret vault. The deploy workflow uploads it with Wrangler's `--secrets-file` support and removes the temporary file after deployment. Do not regenerate it casually: existing encrypted plugin settings require the original key. For a planned rotation, follow EmDash's documented key-rotation procedure.

## 5. Complete first-run setup

Visit `https://<worker-url>/_emdash/admin/` and complete EmDash's setup using your own administrator identity and passkey. Do not create an LLM operator as Admin. After setup:

1. Confirm the ten collections exist.
2. Confirm revisions, search and references work.
3. Create a separate non-admin operator account.
4. Create a narrowly scoped token and start read-only.
5. Enable the `platform-intake` plugin MCP tools after reviewing them.
6. Connect ChatGPT using the MCP endpoint and instructions in `docs/CHATGPT-MCP.md`.
7. Verify the Forms Submissions Inbox and native Comments Inbox are visible. The intake queue is available through the plugin MCP tools.

The public Worker URL is reachable, but the EmDash admin and APIs remain protected by EmDash authentication. Do not rely on a secret URL as access control.

## 6. Optional custom domain

First verify the app on its `workers.dev` URL. To use a custom domain managed in the same Cloudflare account:

1. Add a custom-domain route in `wrangler.jsonc`, for example:

   ```jsonc
   "routes": [
     { "pattern": "workspace.example.com", "custom_domain": true }
   ]
   ```

2. Set the `production` environment variable `EMDASH_SITE_URL` to `https://workspace.example.com` (not a secret). The bootstrap script writes it into Wrangler runtime vars automatically.
3. Push to `main` and wait for deployment. Verify sign-in, passkeys, MCP and absolute URLs on the custom domain.

Set the canonical domain before completing first-run passkey setup where possible. If you have already completed setup on `workers.dev`, use EmDash **Settings → General → Change domain** and verify/re-enrol passkeys as required.

## 7. Ongoing deployments

- Pull requests: GitHub Actions runs scaffold validation, EmDash seed validation, Astro typecheck and a Cloudflare build without Cloudflare credentials.
- Pushes to `main`: checks run, the workflow idempotently provisions/verifies EU D1 and R2, uploads the Worker secret, deploys, and runs the optional HTTP health check.
- Manual deploy: use **Actions → Deploy EmDash Platform to Cloudflare → Run workflow**.
- Dependabot opens weekly dependency and GitHub Actions update PRs; merge only after validation passes.
- Tail logs: `npx wrangler tail`.
- Update dependencies only after reviewing the EmDash changelog and running all checks.

## Data, backups and cost

D1 and R2 are persistent production services. Review Cloudflare's current pricing and usage limits before enabling sustained automation or large media uploads. The initial configuration does not add Vectorize, a Workers AI binding, Durable Objects, sandboxed plugin Worker Loader, public R2 access, an email provider or an n8n deployment. The Forms plugin and append-only intake plugin are installed. Claude-assisted triage remains disabled until its optional secret and model configuration are explicitly supplied. D1 and R2 are provisioned with EU jurisdiction; this constrains where those data stores persist data, but does not by itself guarantee that all Worker request processing occurs only in the EU.

Back up D1 and R2 independently and test restoration. Preserve `EMDASH_ENCRYPTION_KEY` separately. R2 is private by default in this configuration; EmDash serves media through its own route. Do not make the bucket public because backups and other private objects may share it.

The Cron Trigger runs every minute because EmDash's Cloudflare scheduled handler uses it for scheduled publishing and general maintenance. It is part of the app runtime, not a second workflow engine. The minute cron is for EmDash maintenance and scheduled publishing. n8n is deferred and is not required for the current intake/triage path.

## Useful commands

| Command | Purpose |
|---|---|
| `npm run check` | Scaffold, automation-policy, deterministic/LLM triage tests, EmDash seed validation and Astro typecheck |
| `npm run build` | Build the Cloudflare Worker |
| `npm run dev` | Run locally with Cloudflare's Worker runtime |
| `npm run deploy` | Build, provision/verify EU resources, upload runtime secret and deploy (requires Cloudflare environment variables) |
| `npm run cf:types` | Generate Worker binding types from `wrangler.jsonc` |
| `npm run cf:tail` | Stream deployed Worker logs |
| `npm run cf:bootstrap` | Create/verify EU D1 and R2 resources and inject the D1 ID |
| `npm run check:bootstrap` | Test idempotency, EU jurisdiction checks and same-name bucket collisions |
| `npm run check:build-config` | Verify Astro emitted the provisioned D1 ID into the deploy config |
| `npm run cf:smoke` | Check the deployed `/health.json` endpoint |
| `npx wrangler secret put EMDASH_ENCRYPTION_KEY` | Emergency/manual runtime secret update or rotation |
| `npm run check:intelligence` | Verify deterministic-first triage and selective model fallback |

## Calm operating experience, MCP and triage

ChatGPT is the conversational interface and connects through EmDash MCP. The platform also installs the native Forms inbox and an append-only intake queue. Deterministic triage runs first; the optional Claude adapter is called only for ambiguous items and cannot execute actions. It is disabled by default. Email remains the selected notification channel but delivery is not live until a provider is selected and tested. n8n hosting is deferred. See `docs/CHATGPT-MCP.md`, `docs/INTAKE-AND-TRIAGE.md`, `docs/LLM-OPERATING-PROTOCOL.md` and `automation/operating-policy.json`.

A lightweight GitHub uptime workflow checks `/health.json` every six hours once `EMDASH_SITE_URL` is configured. It does not deploy or require Cloudflare credentials.

## Documentation

- [Cloudflare deployment and GitHub Actions](docs/CLOUDFLARE-DEPLOYMENT.md)
- [ChatGPT and MCP connection](docs/CHATGPT-MCP.md)
- [Universal intake and triage](docs/INTAKE-AND-TRIAGE.md)
- [Operators and permissions](docs/OPERATORS.md)
- [Automation and n8n](docs/AUTOMATION.md)
- [Calm operating experience](docs/OPERATING-UX.md)
- [LLM operator protocol](docs/LLM-OPERATING-PROTOCOL.md)
- [n8n operating automations](docs/N8N-OPERATING-AUTOMATION.md)
- [Email notifications](docs/EMAIL-NOTIFICATIONS.md)
- [Tiered LLM autonomy](docs/AUTONOMY-MATURITY.md)
- [Activity and approval boundaries](docs/ACTIVITY.md)
- [Validation and production checklist](docs/VALIDATION.md)
- [Security baseline](docs/SECURITY.md)
- [EmDash source verification](docs/EMDASH-SOURCE-VERIFICATION.md)

## Upstream preservation

This project consumes published EmDash packages. Upgrades are dependency changes in this repository, reviewed with the seed validator, typecheck, Cloudflare build, MCP operator tests and rollback plan. Do not copy EmDash's `packages/core`, `packages/admin` or `packages/auth` into this repository.
