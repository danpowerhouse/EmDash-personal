# Security baseline

- Keep the Cloudflare D1 and R2 resources in the intended EU jurisdiction; verify live resources before using them.
- Keep R2 private and do not publish the bucket.
- Never commit `.dev.vars`, `.secrets.generated.json`, API keys, PATs or OAuth tokens.
- Use the owner's Admin account only for administration; ChatGPT connects through a dedicated Contributor identity and narrow MCP scopes.
- Grant `content:read` initially; add `media:read` only if needed. The append-only `platform-intake` MCP tools require their own plugin scope.
- Plugin MCP tools are disabled until explicitly enabled by an administrator.
- The intake plugin has only an append-only capture tool plus read/list tools; it does not expose update/delete or operational content writes.
- The optional Anthropic API key is a Worker secret. It is used only for ambiguous triage when `TRIAGE_LLM_ENABLED=true`, the provider and model are configured, and deterministic rules did not classify the item.
- Captured content sent to Anthropic is external data processing. Review applicable privacy terms, retention and residency before enabling it.
- Triage output is validated and never executed. No tool access is given to the triage model.
- The Forms plugin is trusted in-process code. Review its first-party source and requested capabilities; enable public forms only with spam controls and data-retention settings appropriate to the information collected.
- Workspace/organisation fields are grouping metadata, not security boundaries.
- Keep high-impact actions behind explicit human approval.
