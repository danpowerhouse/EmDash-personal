# Validation and production checklist

Run checks against the local Cloudflare Worker runtime first, then repeat operator and recovery tests against a disposable staging Worker/D1/R2 set. EmDash remains the authority for schema, permissions and runtime behavior.

## 1. Validate the seed and build

```bash
npm run check:scaffold
npm run check:automation
npm run check:intelligence
npm run seed:validate
npm run typecheck
npm run build
```

Pass when all commands exit successfully and EmDash reports `Seed file is valid`. The custom check verifies the intended ten collections, required workspace/organisation references and local invariants. It does not replace EmDash's `validateSeed()`.

The seed is embedded through `package.json#emdash.seed`. On first request, EmDash applies the schema/structure during first-run setup. Do not use the local SQLite-oriented CLI seed apply command to populate D1.

After first-run setup, verify in **Settings → Content Types** and the content collection list:

- Exactly the ten expected collections exist.
- Each is non-routable and has revisions/search enabled.
- Reference pickers resolve to the expected target collections.
- `workspace` and `organisation` references exist on goals and all seven operational collections.
- Record creation, editing, revision history, search and reference selection work.

## 2. Verify installed intake and MCP capabilities

- Confirm the Forms plugin is active and its Forms and Submissions pages load.
- Confirm the Comments Inbox remains visible in the EmDash admin.
- Confirm `platform-intake` is active and its `capture`, `list` and `get` MCP tools are available after an administrator explicitly enables them.
- Capture a harmless test item from ChatGPT/MCP; verify the original content, source, timestamp and triage metadata are preserved.
- Confirm the capture tool cannot update/delete operational records or execute the suggested action.
- Confirm deterministic examples are classified without an external model call.
- With `TRIAGE_LLM_ENABLED=false`, submit an ambiguous item and confirm it remains in human review without calling Anthropic.
- Only after a human explicitly enables the provider, test one ambiguous item with a valid Anthropic key/model and verify the result remains `needs_human_review`.

## 3. Prove workspace/organisation fields are not access control

Create two workspaces and two organisations, then create records under each. Use an operator account with ordinary collection read permission. Confirm it can read records from both contexts regardless of workspace field.

Pass criterion: everyone understands that these fields are grouping metadata, not tenant isolation. Never put data requiring cross-workspace confidentiality in one shared EmDash instance without a separately verified authorization boundary.

## 4. Verify real role and token behavior

Create separate test identities and PATs. Role and token scopes are independent gates.

- Subscriber + `content:read`: published-content read/search only; draft operational records are hidden.
- Contributor + `content:read`: can read drafts and published operational records, but cannot create/update/publish/delete because the token lacks `content:write`. This is the intended read-only operator profile.
- Author + `content:read` + `content:write`: can create and act on owned records; cannot edit/delete another user's record where Editor-level permissions are required.
- Author cannot change collection schema or site settings.
- Editor can manage all users' content and read schemas/settings, but token scopes still apply.
- Admin is required for schema/settings writes and plugin/user administration.

Test delete denial against a record owned by a different user. An Author can delete its own content under built-in ownership rules. Verify both the returned denial and that the record remains unchanged.

## 5. Verify n8n is deferred

The initial deployment does not depend on n8n and does not install the webhook notifier. EmDash admin, records, search, intake capture and MCP must work without n8n.

## 6. Verify the ChatGPT MCP loop

Use a non-admin test account and the real remote MCP endpoint:

1. `initialize` and `tools/list` succeed with the dedicated ChatGPT authorization.
2. List/read a draft operational record as a Contributor.
3. Search for a known term.
4. Call `platform-intake__capture` with a harmless note, then retrieve it with `platform-intake__get`.
5. Confirm `platform-intake__list` returns the captured item and its triage method.
6. Confirm ordinary content create/update/delete/publish operations are denied because the connector has no general `content:write` scope.
7. Confirm schema and settings writes are denied.
8. If a separate write-capable operator is later approved, test its allowed/denied operations with a disposable account and records; do not broaden ChatGPT's default connector scope for that test.

Keep the test account, role, token scopes (never token value), date and actual results. Verify the action did not occur as well as reading any error.

For a non-destructive smoke check, set `EMDASH_MCP_URL` and `EMDASH_MCP_TOKEN` in your shell and run `npm run check:mcp` if the script is present in the project. It only initializes MCP and lists tools; it does not run write/denial tests.

## Production gate

- [ ] Seed validation, Astro typecheck and Cloudflare production build pass.
- [ ] GitHub Actions secrets include the Cloudflare API token, account ID and EmDash encryption key; Anthropic key is optional and only present when triage fallback is deliberately enabled.
- [ ] `EMDASH_ENCRYPTION_KEY` is set as a Worker secret and recovery is documented.
- [ ] D1 backup/export and restore are tested.
- [ ] R2 backup and restore are tested separately.
- [ ] HTTPS, canonical URL, passkey login, cookies and MCP origin are verified.
- [ ] The audit plugin's actual coverage and limitations are understood.
- [ ] Operator identities, token scopes, expiration and revocation are tested.
- [ ] n8n remains deferred and is not required for the platform.
- [ ] Forms, Comments and platform-intake MCP tools are verified.
- [ ] Deterministic triage is tested; Anthropic fallback is disabled unless explicitly approved/configured.
- [ ] Cron Trigger and scheduled handler are both present and verified.
- [ ] Logs, errors, backups and incident recovery have named owners.


## Additional operator visibility check

The dedicated Contributor + `content:read` test above is mandatory because EmDash MCP creates drafts by default and Subscribers cannot read them. Confirm this behavior against the exact pinned EmDash release after every major upgrade.


## 2026-11-01 deployment hardening review

The deployment workflows now require a committed lockfile, use immutable action SHAs and read-only repository permissions. Production dependency audit is reported but does not block deployment; pull-request audit remains a gate. Cloudflare bootstrap runs before Astro build, verifies EU and default R2 namespaces, and the build output is checked for the provisioned D1 ID. The bootstrap regression test is `npm run check:bootstrap`. Intake capture requires `content:create`; list/get require `content:read_drafts`; list returns summaries only. `.wrangler/` is ignored, `TRIAGE_MODEL` is in Wrangler vars, provider errors are logged without source content, and Worker observability is enabled.

Still required before first GitHub run: generate and commit `package-lock.json` with `npm install` on a machine that can reach the npm registry. This environment could not resolve the npm registry, so it would be unsafe to fabricate a lockfile. The full dependency install, EmDash seed validator, Astro typecheck and production build have not yet been executed here.
