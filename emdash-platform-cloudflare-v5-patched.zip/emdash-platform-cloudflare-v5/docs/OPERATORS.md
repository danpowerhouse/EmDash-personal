# Human and AI access

## Operating model

EmDash is the system of record, admin and MCP server. **ChatGPT is the conversational interface** and connects to the existing endpoint:

```text
https://YOUR_PUBLIC_HOST/_emdash/api/mcp
```

The platform does not install another chat interface. A separate, narrow background triage module may call Claude only when deterministic intake rules cannot classify an item. It is not an operator with MCP tools and cannot execute actions.

## Identity model

Use a distinct EmDash user identity for each human or automated integration. Do not share the owner's Admin account or token. Create and rotate a dedicated token/OAuth grant for ChatGPT.

| Role | Level | Appropriate use |
|---|---:|---|
| Subscriber | 10 | Published content only; unsuitable for operational drafts |
| Contributor | 20 | Minimum role for reading operational drafts |
| Author | 30 | Edit/publish owned content and manage own media |
| Editor | 40 | Manage all users' content and selected site structures |
| Admin | 50 | Manage users, schema, settings, plugins and system-level actions |

EmDash core RBAC is role-based and ownership-based. It does not provide per-workspace, per-organisation, per-record or per-field authorization.

## Initial ChatGPT connection

Use a dedicated **Contributor** identity. Contributor is the minimum role with `content:read_drafts`; Subscriber is published-only. Start with `content:read`, adding `media:read` only if necessary.

The `platform-intake` plugin exposes append-only capture, list and get tools. Enable those tools in EmDash after reviewing them, then grant the connector `mcp:tools:platform-intake`. Capturing an inbox item writes only to the plugin's intake storage; it does not grant general content-write access.

Do not grant `content:write`, `admin`, `schema:write`, `settings:manage`, `transfer:execute` or plugin-management scopes by default. See `docs/CHATGPT-MCP.md` for connection and verification steps.

## Background triage identity and provider

The background triage module is invoked inside the intake plugin, not through a separate MCP operator identity. Its initial provider adapter is Anthropic/Claude. It receives only ambiguous intake content and returns a validated classification proposal. It has no EmDash credentials or tool access.

Keep `TRIAGE_LLM_ENABLED=false` until the Anthropic key, model, data-processing implications and tests have been reviewed. A missing key/model or provider failure results in human review; capture remains available.

## Permission verification

- Contributor + `content:read` can read operational drafts but cannot use core content write tools without `content:write`.
- The intake plugin's `capture` tool is a narrow append-only operation protected by its own plugin MCP scope.
- Plugin MCP tools must be explicitly enabled by an administrator.
- Never expose an Admin token to ChatGPT, n8n, a browser extension or source control.

## Workspace and organisation boundaries

`workspace` and `organisation` fields are grouping metadata, not access-control boundaries. An operator with collection read access may read records across all workspaces and organisations. Use separate deployments/databases for data requiring actual separation.
