# Universal intake and intelligent triage

## Design decision

The Universal Inbox is an intake layer, not a replacement CMS and not a second workflow engine. EmDash remains the system of record. Reuse native EmDash intake features and add only the missing cross-channel capture and triage capability.

## Installed EmDash capabilities

- Core Comments Inbox remains visible in the admin.
- `@emdash-cms/plugin-forms` is installed and registered. It provides form definitions, public submissions, attachments, spam protection, submission states, export and notification hooks. Its submissions remain in the Forms plugin's own inbox.
- EmDash Media Library remains the file store.
- Core content collections, revisions, search, REST and MCP remain the operational record layer.
- The audit-log plugin remains installed.

The Forms Submissions Inbox and Comments Inbox are native EmDash inboxes. They are not silently copied into the platform intake queue. A later connector can aggregate them through supported plugin APIs or explicit webhooks after their data contracts and permissions are verified.

## Platform intake plugin

The local trusted plugin `platform-intake` adds an append-only intake queue in EmDash plugin storage and exposes three MCP tools:

- `platform-intake__capture`: append an item with source, title, content and optional source reference; run triage; return the item ID and triage result.
- `platform-intake__list`: list recent items.
- `platform-intake__get`: retrieve the original captured item.

The capture route is intentionally append-only. It does not create tasks, update projects, send email, publish content, delete records or execute suggested actions. It uses the `content:read` route permission plus the plugin-specific MCP tool scope. Enable the plugin MCP tools in EmDash only after reviewing their definitions.

The first intake sources are ChatGPT/MCP, web/manual capture and API. Forms, inbound email, voice transcription and file extraction can be connected later. Forms already supports attachments in its own submissions inbox. The platform-intake queue is initially accessed through ChatGPT/MCP tools; this revision does not yet add a separate aggregate admin inbox screen. The native Forms and Comments inboxes remain visible in EmDash.

## Deterministic-first triage

`src/lib/intelligence/` contains a provider-neutral contract, deterministic classifier, Anthropic adapter and orchestration function.

1. Deterministic rules inspect explicit labels and unambiguous task/decision/idea/reference markers.
2. If exactly one rule matches, the item is classified without a model call.
3. If rules do not match or conflict, the result is ambiguous.
4. Only ambiguous items are eligible for the optional LLM fallback.
5. The LLM returns a constrained classification proposal. The response is parsed and validated before storage.
6. LLM-derived classifications remain `needs_human_review`; no action is executed and no operational record is created automatically.
7. If the provider is disabled, missing configuration, times out or returns invalid output, capture still succeeds and the item is marked for human review.

The model is called from the intake route only when `TRIAGE_LLM_ENABLED=true`, the configured provider is `anthropic`, and both `TRIAGE_MODEL` and `ANTHROPIC_API_KEY` are present. It receives only the item title, source and content (capped at 12,000 characters). The prompt treats captured material as untrusted data and exposes no tools.

## Existing EmDash AI is not reused as generic triage

- The first-party AI Moderation plugin uses Cloudflare Workers AI / Llama Guard for comment safety classification. It is not a general intake classifier and is not installed here.
- The first-party AI Search plugin uses Cloudflare AI Search for indexing/search, with optional query rewriting and reranking. It is not a general-purpose reasoning API and is not installed here.
- EmDash core MCP is a tool server, not an LLM runtime.

This separation avoids calling an LLM on every comment or search and keeps triage provider-independent.

## Configuration

Default configuration is fail-closed:

```jsonc
"vars": {
  "TRIAGE_LLM_ENABLED": "false",
  "TRIAGE_LLM_PROVIDER": "anthropic"
}
```

To enable Claude-assisted fallback after reviewing data-processing implications:

1. Add `ANTHROPIC_API_KEY` as a GitHub production environment secret (and local `.dev.vars` secret for local development).
2. Set `TRIAGE_MODEL` in `wrangler.jsonc` to an Anthropic model currently available to the account. It is declared as a Wrangler variable so deployments do not erase it.
3. Change `TRIAGE_LLM_ENABLED` to `true`.
4. Deploy and test both deterministic and ambiguous cases.

Do not place the API key in `wrangler.jsonc`, source control, the seed, or a client-side bundle. The deployment workflow includes the optional secret only when provided. If it is absent, triage falls back to human review.

## Deliberate exclusions

- No in-platform conversational AI UI. Conversation remains in ChatGPT.
- No automatic action execution from triage.
- No automatic merge of Forms/Comments inboxes into the platform queue yet.
- No inbound email provider configured yet.
- No voice transcription or OCR pipeline yet.
- No n8n dependency.
